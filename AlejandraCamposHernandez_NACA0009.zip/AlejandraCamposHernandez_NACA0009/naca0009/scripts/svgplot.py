#!/usr/bin/env python3
"""
svgplot.py -- gráficas SVG con Python puro (sin matplotlib), para los scripts de este caso.

El Python que trae blueCFD no siempre incluye matplotlib; los .svg se abren con cualquier navegador
(doble clic) y se pueden insertar en LaTeX o convertir a PDF/PNG desde ahí.

    from svgplot import figura
    figura("salida.svg", [panel, panel, ...], columnas=2)

    panel = {"titulo": "...", "xlabel": "...", "ylabel": "...", "logy": False,
             "xlim": (a, b), "ylim": (a, b),                 # opcionales
             "bandas": [(x0, x1)],                           # franjas sombreadas (por ejemplo la ventana final)
             "lineas_h": [(y, "etiqueta")],                  # rectas horizontales discontinuas
             "series": [{"x": [...], "y": [...], "etiqueta": "...", "estilo": "linea" | "puntos" | "ambos",
                         "color": "#1f77b4", "discontinua": False}]}
"""
import math
from xml.sax.saxutils import escape

COLORES = ["#1f77b4", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd", "#8c564b", "#17becf"]


def _ticks_lin(a, b, n=6):
    if b <= a:
        a, b = a - 1, b + 1
    raw = (b - a) / n
    mag = 10 ** math.floor(math.log10(raw))
    paso = next(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
    v = math.ceil(a / paso - 1e-9) * paso
    out = []
    while v <= b + 1e-9 * paso:
        out.append(round(v, 12))
        v += paso
    return out


def _ticks_log(a, b):
    return [10.0 ** k for k in range(math.floor(math.log10(a)), math.ceil(math.log10(b)) + 1)]


def _fmt(v):
    if v == 0:
        return "0"
    if abs(v) >= 1e5 or abs(v) < 1e-3:
        m, e = f"{v:.0e}".split("e")
        return f"{m}e{int(e)}"
    return f"{v:g}"


def _panel(x0, y0, w, h, p):
    ml, mr, mt, mb = 66, 16, 30, 46
    px, py, pw, ph = x0 + ml, y0 + mt, w - ml - mr, h - mt - mb
    logy = p.get("logy", False)
    series = []
    for s in p["series"]:
        pares = [(a, b) for a, b in zip(s["x"], s["y"]) if a is not None and b is not None and (b > 0 or not logy)]
        if pares:
            series.append((s, pares))
    out = [f'<rect x="{px}" y="{py}" width="{pw}" height="{ph}" fill="white" stroke="#444"/>']
    out.append(f'<text x="{px + pw / 2}" y="{y0 + 18}" text-anchor="middle" font-size="13" font-weight="bold">{escape(p.get("titulo", ""))}</text>')
    if not series:
        out.append(f'<text x="{px + pw / 2}" y="{py + ph / 2}" text-anchor="middle" font-size="12" fill="#888">sin datos</text>')
        return "\n".join(out)

    xs = [a for _, pr in series for a, _ in pr]
    ys = [b for _, pr in series for _, b in pr]
    if p.get("xlim"):
        xa, xb = p["xlim"]
    else:
        xa, xb = min(xs), max(xs)
        if p.get("rellenar_x", True) and any(s.get("estilo", "linea") != "linea" for s, _ in series):
            xa, xb = xa - 0.03 * ((xb - xa) or 1), xb + 0.03 * ((xb - xa) or 1)      # que los puntos de los extremos no se corten
    if "ylim" in p and p["ylim"]:
        ya, yb = p["ylim"]
    elif logy:
        ya, yb = 10 ** math.floor(math.log10(min(ys))), 10 ** math.ceil(math.log10(max(ys)))
    else:
        ya, yb = min(ys), max(ys)
        pad = 0.06 * ((yb - ya) or abs(ya) or 1)
        ya, yb = ya - pad, yb + pad
    if xb == xa:
        xb = xa + 1
    if yb == ya:
        yb = ya + 1

    def fx(v):
        return px + (v - xa) / (xb - xa) * pw

    def fy(v):
        if logy:
            return py + ph - (math.log10(max(v, 1e-300)) - math.log10(ya)) / (math.log10(yb) - math.log10(ya)) * ph
        return py + ph - (v - ya) / (yb - ya) * ph

    out.append(f'<clipPath id="c{abs(hash((x0, y0)))}"><rect x="{px}" y="{py}" width="{pw}" height="{ph}"/></clipPath>')
    clip = f'clip-path="url(#c{abs(hash((x0, y0)))})"'
    for t in _ticks_lin(xa, xb):
        out.append(f'<line x1="{fx(t):.1f}" y1="{py}" x2="{fx(t):.1f}" y2="{py + ph}" stroke="#e3e3e3"/>')
        out.append(f'<text x="{fx(t):.1f}" y="{py + ph + 15}" text-anchor="middle" font-size="11">{_fmt(t)}</text>')
    for t in (_ticks_log(ya, yb) if logy else _ticks_lin(ya, yb)):
        if ya - 1e-12 <= t <= yb * (1 + 1e-12) if logy else ya <= t <= yb:
            out.append(f'<line x1="{px}" y1="{fy(t):.1f}" x2="{px + pw}" y2="{fy(t):.1f}" stroke="#e3e3e3"/>')
            out.append(f'<text x="{px - 6}" y="{fy(t) + 4:.1f}" text-anchor="end" font-size="11">{_fmt(t)}</text>')
    out.append(f'<text x="{px + pw / 2}" y="{y0 + h - 6}" text-anchor="middle" font-size="12">{escape(p.get("xlabel", ""))}</text>')
    out.append(f'<text transform="translate({x0 + 14},{py + ph / 2}) rotate(-90)" text-anchor="middle" font-size="12">{escape(p.get("ylabel", ""))}</text>')

    for b0, b1 in p.get("bandas", []):
        a, b = max(fx(b0), px), min(fx(b1), px + pw)
        if b > a:
            out.append(f'<rect x="{a:.1f}" y="{py}" width="{b - a:.1f}" height="{ph}" fill="#ffd54f" fill-opacity="0.25"/>')
    for yv, et in p.get("lineas_h", []):
        if ya <= yv <= yb:
            out.append(f'<line x1="{px}" y1="{fy(yv):.1f}" x2="{px + pw}" y2="{fy(yv):.1f}" stroke="#666" stroke-dasharray="5,4"/>')
            out.append(f'<text x="{px + pw - 4}" y="{fy(yv) - 4:.1f}" text-anchor="end" font-size="10" fill="#444">{escape(et)}</text>')

    for i, (s, pr) in enumerate(series):
        col = s.get("color") or COLORES[i % len(COLORES)]
        est = s.get("estilo", "linea")
        paso = max(1, len(pr) // 1500)                      # no más de unos 1500 puntos por curva
        pr_d = pr[::paso] + ([pr[-1]] if pr[-1] not in pr[::paso] else [])
        if est in ("linea", "ambos") and len(pr_d) > 1:
            d = " ".join(f"{fx(a):.1f},{fy(b):.1f}" for a, b in pr_d)
            dash = ' stroke-dasharray="6,4"' if s.get("discontinua") else ""
            out.append(f'<polyline {clip} points="{d}" fill="none" stroke="{col}" stroke-width="1.5"{dash}/>')
        if est in ("puntos", "ambos") or len(pr_d) == 1:
            for a, b in pr_d:
                out.append(f'<circle {clip} cx="{fx(a):.1f}" cy="{fy(b):.1f}" r="3.2" fill="{"white" if s.get("hueco") else col}" stroke="{col}"/>')

    # leyenda (sólo con más de una serie con etiqueta)
    con_et = [(i, s) for i, (s, _) in enumerate(series) if s.get("etiqueta")]
    if len(con_et) > 1 or (len(con_et) == 1 and p.get("leyenda_siempre")):
        ancho = 14 + 7 * max(len(s["etiqueta"]) for _, s in con_et) + 24
        lx, ly = (px + pw - ancho, py + 8) if p.get("leyenda") == "derecha" else (px + 8, py + 8)
        out.append(f'<rect x="{lx - 4}" y="{ly - 4}" width="{ancho}" height="{16 * len(con_et) + 4}" fill="white" fill-opacity="0.85" stroke="#bbb"/>')
        for k, (i, s) in enumerate(con_et):
            col = s.get("color") or COLORES[i % len(COLORES)]
            yy = ly + 8 + 16 * k
            if s.get("estilo", "linea") == "puntos":
                out.append(f'<circle cx="{lx + 8}" cy="{yy - 3}" r="3.2" fill="{"white" if s.get("hueco") else col}" stroke="{col}"/>')
            else:
                out.append(f'<line x1="{lx}" y1="{yy - 3}" x2="{lx + 16}" y2="{yy - 3}" stroke="{col}" stroke-width="2"/>')
            out.append(f'<text x="{lx + 22}" y="{yy}" font-size="11">{escape(s["etiqueta"])}</text>')
    return "\n".join(out)


def figura(ruta, paneles, columnas=2, ancho_panel=520, alto_panel=340):
    filas = math.ceil(len(paneles) / columnas)
    W, H = columnas * ancho_panel, filas * alto_panel
    partes = [f'<?xml version="1.0" encoding="UTF-8"?>',
              f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
              f'font-family="Helvetica, Arial, sans-serif">',
              f'<rect width="{W}" height="{H}" fill="white"/>']
    for i, p in enumerate(paneles):
        partes.append(_panel((i % columnas) * ancho_panel, (i // columnas) * alto_panel, ancho_panel, alto_panel, p))
    partes.append("</svg>")
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(partes) + "\n")
    return ruta
