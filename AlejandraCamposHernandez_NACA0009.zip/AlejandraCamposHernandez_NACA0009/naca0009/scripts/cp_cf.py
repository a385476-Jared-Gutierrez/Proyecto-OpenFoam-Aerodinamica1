#!/usr/bin/env python3
"""
cp_cf.py -- cp(x/c) y cf(x/c) del perfil, ordenados por superficie, en CSV y en gráfica.

Uso:
    python cp_cf.py casos/base_media/a8 [casos/base_media/a0 ...]

Cada carpeta es la de un ángulo (la que crea Allpolar). Lee system/controlDict (magUInf y liftDir, de donde
sale alfa) y postProcessing/pared/<iteración>/*.xy, que escribe la función patchSurface del controlDict:
una fila por cara del perfil con  x y z p tau_x tau_y tau_z y+  (p cinemática, tau cinemático).

Definiciones (hoja del proyecto y tutorial 2.1; presión de referencia p_inf = 0 y p cinemática, así que no se
divide otra vez por la densidad):
    cp = p / (U^2 / 2)         cf = (tau . t) / (U^2 / 2)       t = tangente unitaria de borde de ataque a borde de salida

Escribe en la carpeta del ángulo:
    cp_cf_a<alfa>.csv   superficie, x/c, y/c, cp, cf, y+  (extradós de borde de ataque a salida, luego intradós)
    cp_cf_a<alfa>.png   -cp contra x/c (succión arriba) y cf del extradós
y en pantalla: cp mínimo y su posición, cp máximo (remanso), y el CL que sale de integrar sólo la presión
(una comprobación: debe quedar cerca del CL de forceCoeffs; la fricción aporta muy poco a la sustentación).

Signo de cf: la convención de signo de wallShearStress se comprueba en cada corrida. Con --signo auto (por omisión)
se elige el signo que hace positivo el cf mediano del extradós entre 10 y 50 % de la cuerda, donde el flujo
está pegado a ángulos moderados; a ángulos altos, con desprendimiento ahí, fije el signo con --signo 1 o -1
(el que salió en las corridas pegadas). cf < 0 es flujo de retorno, es decir, separación.
"""
import argparse
import glob
import math
import os
import re
import sys


def ultimo(patron):
    rutas = glob.glob(patron)
    if not rutas:
        return None
    def clave(r):
        m = re.search(r"/(\d+(?:\.\d+)?)/[^/]*$", r.replace("\\", "/"))
        return float(m.group(1)) if m else -1.0
    return sorted(rutas, key=clave)[-1]


def leer_caso(carpeta):
    with open(os.path.join(carpeta, "system", "controlDict"), encoding="utf-8") as f:
        cd = f.read()
    U = float(re.search(r"magUInf=([0-9.eE+-]+)", cd).group(1))
    lx, ly = (float(v) for v in re.search(r"liftDir=\(([-0-9.eE+]+) ([-0-9.eE+]+)", cd).groups())
    alfa = math.degrees(math.atan2(-lx, ly))              # liftDir = (-sin a, cos a)
    return U, alfa


def leer_xy(ruta):
    pts = []
    with open(ruta, encoding="utf-8", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if not s or s.startswith("#"):
                continue
            try:
                v = [float(c) for c in s.split()]
            except ValueError:
                continue
            if len(v) >= 8:
                pts.append(v[:8])
    return pts


def ordenar(pts):
    """Devuelve (extrados, intrados), cada uno de borde de ataque a borde de salida, y el contorno completo
    en sentido antihorario (para integrar). Cada punto es la fila original de 8 columnas."""
    xc = sum(p[0] for p in pts) / len(pts)
    yc = sum(p[1] for p in pts) / len(pts)
    ciclo = sorted(pts, key=lambda p: math.atan2(p[1] - yc, p[0] - xc))          # antihorario
    n = len(ciclo)
    iLE = min(range(n), key=lambda i: ciclo[i][0])
    iTE = max(range(n), key=lambda i: ciclo[i][0])
    # de LE a TE siguiendo el ciclo, y el resto (de LE a TE al revés)
    seg1 = [ciclo[(iLE + k) % n] for k in range(((iTE - iLE) % n) + 1)]
    seg2 = [ciclo[(iLE - k) % n] for k in range(((iLE - iTE) % n) + 1)]
    if sum(p[1] for p in seg1) / len(seg1) > sum(p[1] for p in seg2) / len(seg2):
        return seg1, seg2, ciclo
    return seg2, seg1, ciclo


def tangentes(seg):
    t = []
    for i in range(len(seg)):
        a, b = seg[max(i - 1, 0)], seg[min(i + 1, len(seg) - 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        d = math.hypot(dx, dy) or 1.0
        t.append((dx / d, dy / d))
    return t


def fuerzas_presion(ciclo, cp, c):
    """Fx, Fy (coeficientes, por cuerda) de integrar -p n dl en el contorno antihorario cerrado por segmentos."""
    n = len(ciclo)
    fx = fy = 0.0
    for i in range(n):
        a, b = ciclo[i], ciclo[(i + 1) % n]
        pm = 0.5 * (cp[i] + cp[(i + 1) % n])
        dx, dy = b[0] - a[0], b[1] - a[1]
        fx += -pm * dy          # normal exterior dl = (dy, -dx) en recorrido antihorario
        fy += pm * dx
    return fx / c, fy / c


def procesar(carpeta, signo, c, sin_grafica, forzar_svg=False):
    U, alfa = leer_caso(carpeta)
    ruta = ultimo(os.path.join(carpeta, "postProcessing", "pared", "*", "*.xy"))
    if not ruta:
        print(f"{carpeta}: no hay postProcessing/pared/*/*.xy"); return
    pts = leer_xy(ruta)
    if not pts:
        print(f"{carpeta}: {ruta} no tiene filas de 8 columnas"); return
    ex, inn, ciclo = ordenar(pts)
    q = 0.5 * U * U

    def tabla(seg):
        t = tangentes(seg)
        return [(p[0] / c, p[1] / c, p[3] / q, ((p[4] * tx + p[5] * ty) / q), p[7]) for p, (tx, ty) in zip(seg, t)]

    te, ti = tabla(ex), tabla(inn)
    s = signo
    if s == 0:
        med = sorted(r[3] for r in te if 0.1 <= r[0] <= 0.5)
        if not med:
            s = 1
            print("  Aviso: no hay puntos del extradós entre 10 y 50 % para fijar el signo de cf; use --signo")
        else:
            s = 1 if med[len(med) // 2] >= 0 else -1
    te = [(a, b, cp, s * cf, yp) for a, b, cp, cf, yp in te]
    ti = [(a, b, cp, s * cf, yp) for a, b, cp, cf, yp in ti]

    nombre = f"cp_cf_a{alfa:g}"
    with open(os.path.join(carpeta, nombre + ".csv"), "w", encoding="utf-8") as f:
        f.write("superficie,x_c,y_c,cp,cf,yplus\n")
        for etiqueta, tb in (("extrados", te), ("intrados", ti)):
            for a, b, cp, cf, yp in tb:
                f.write(f"{etiqueta},{a:.6f},{b:.6f},{cp:.6f},{cf:.6e},{yp:.4f}\n")

    todos = te + ti
    cpmin = min(todos, key=lambda r: r[2])
    cpmax = max(todos, key=lambda r: r[2])
    cps = [p[3] / q for p in ciclo]
    fx, fy = fuerzas_presion(ciclo, cps, c)
    a = math.radians(alfa)
    cl_p = -math.sin(a) * fx + math.cos(a) * fy
    cd_p = math.cos(a) * fx + math.sin(a) * fy
    cfn = [r[3] for r in te if r[0] > 0.02]
    sep = [r[0] for r in te if r[3] < 0 and r[0] > 0.02]
    print(f"\n=== {carpeta}: alfa = {alfa:g}°, U = {U:g} m/s, {len(pts)} caras ({ruta})")
    print(f"  cp mínimo {cpmin[2]:.3f} en x/c = {cpmin[0]:.4f};  cp máximo {cpmax[2]:.3f} en x/c = {cpmax[0]:.4f}")
    print(f"  Integrando sólo la presión: CL = {cl_p:.4f}, CD de presión = {cd_p:.5f}  "
          f"(compare con forceCoeffs/forces.dat; la integral usa los centros de cara, es una comprobación, no el valor final)")
    print(f"  Signo de cf aplicado: {'+' if s > 0 else '-'} ({'automático' if signo == 0 else 'fijado'}); "
          f"extradós: cf mínimo {min(cfn):.5f}" + (f", cf < 0 desde x/c = {min(sep):.3f} (flujo de retorno)" if sep else ", sin flujo de retorno"))
    print(f"  Escribí {os.path.join(carpeta, nombre + '.csv')}")

    if not sin_grafica:
        plt = None
        if not forzar_svg:
            try:
                import matplotlib
                matplotlib.use("Agg")
                import matplotlib.pyplot as plt
            except ImportError:
                plt = None
        if plt is None:                                     # sin matplotlib: SVG con Python puro
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from svgplot import figura
            cf_ok = [r for r in te + ti if r[0] > 0.02]
            figura(os.path.join(carpeta, nombre + ".svg"), [
                {"titulo": f"-cp, alfa = {alfa:g}°, U = {U:g} m/s", "xlabel": "x/c", "ylabel": "-cp",
                 "series": [{"x": [r[0] for r in te], "y": [-r[2] for r in te], "etiqueta": "extradós"},
                            {"x": [r[0] for r in ti], "y": [-r[2] for r in ti], "etiqueta": "intradós"}]},
                {"titulo": "cf (la nariz sale de la escala)", "xlabel": "x/c", "ylabel": "cf",
                 "ylim": (min(-0.002, min(r[3] for r in cf_ok) * 1.2), max(r[3] for r in cf_ok) * 1.2),
                 "lineas_h": [(0.0, "")],
                 "series": [{"x": [r[0] for r in te], "y": [r[3] for r in te], "etiqueta": "extradós"},
                            {"x": [r[0] for r in ti], "y": [r[3] for r in ti], "etiqueta": "intradós"}]}], columnas=2)
            print(f"  Escribí {os.path.join(carpeta, nombre + '.svg')}")
            return
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
        ax[0].plot([r[0] for r in te], [-r[2] for r in te], "-", color="tab:blue", label="extradós")
        ax[0].plot([r[0] for r in ti], [-r[2] for r in ti], "-", color="tab:red", label="intradós")
        ax[0].set_xlabel("x/c"); ax[0].set_ylabel("$-c_p$"); ax[0].grid(alpha=0.3); ax[0].legend()
        ax[0].set_title(f"Presión superficial, α = {alfa:g}°, U∞ = {U:g} m/s")
        ax[1].plot([r[0] for r in te], [r[3] for r in te], "-", color="tab:blue", label="extradós")
        ax[1].plot([r[0] for r in ti], [r[3] for r in ti], "-", color="tab:red", label="intradós")
        ax[1].axhline(0, color="k", lw=0.5)
        ax[1].set_xlabel("x/c"); ax[1].set_ylabel("$c_f$"); ax[1].grid(alpha=0.3); ax[1].legend()
        top = max(r[3] for r in te if r[0] > 0.05) * 1.5 if any(r[0] > 0.05 for r in te) else 0.01
        ax[1].set_ylim(min(-0.002, min(r[3] for r in te + ti if r[0] > 0.02) * 1.2), top)
        ax[1].set_title("Fricción (la nariz sale de la escala)")
        fig.tight_layout()
        fig.savefig(os.path.join(carpeta, nombre + ".png"), dpi=150)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("carpetas", nargs="+")
    ap.add_argument("--signo", type=int, choices=(-1, 0, 1), default=0, help="signo de cf: 0 automático (por omisión), 1 o -1")
    ap.add_argument("--cuerda", type=float, default=1.0)
    ap.add_argument("--sin-grafica", action="store_true")
    ap.add_argument("--svg", action="store_true", help="forzar .svg aunque haya matplotlib")
    a = ap.parse_args()
    for c in a.carpetas:
        procesar(c.rstrip("/\\"), a.signo, a.cuerda, a.sin_grafica, a.svg)


if __name__ == "__main__":
    main()
