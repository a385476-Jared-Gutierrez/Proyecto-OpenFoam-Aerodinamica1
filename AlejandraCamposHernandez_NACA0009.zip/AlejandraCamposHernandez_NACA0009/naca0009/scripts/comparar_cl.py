#!/usr/bin/env python3
"""
comparar_cl.py -- CL(alfa) de la simulación contra datos experimentales.

Uso:
    python comparar_cl.py polar.dat experimento.csv --naca 2415 \
        --rango-lineal -4 8 --titulo "NACA 2415, Re = 6e6"

Entradas
  polar.dat       Tabla de la simulación (la que escribe verificar.py / Allpolar):
                  columnas  alfa  CL  CD  Cm  iteraciones  estado   (las líneas con # se ignoran;
                  sólo hacen falta las dos primeras; 'estado' es opcional).
  experimento.csv Datos de ensayo, columnas  alfa,CL  (coma, espacio o tabulador).
                  Las líneas que empiezan con # son comentarios: ponga ahí la fuente,
                  el Reynolds, el Mach y si el dato es medición o digitalización.

Salidas (con el prefijo --salida, por omisión 'comparacion_cl')
  <prefijo>.svg   gráfica CL contra alfa (con matplotlib instalado, .png; con --svg se fuerza el .svg)
  <prefijo>.csv   tabla punto por punto
  y en pantalla:  pendiente, alfa de sustentación nula, diferencias, CL máximo observado.

No extrapola: el CL experimental se interpola sólo dentro del intervalo de alfa medido.
Sólo usa la biblioteca estándar de Python (la gráfica .png es opcional si hay matplotlib).
"""
import argparse
import math
import os
import sys


# ----------------------------------------------------------------------------- lectura
def _ordenar(*listas):
    o = sorted(range(len(listas[0])), key=lambda k: listas[0][k])
    return [[l[k] for k in o] for l in listas]


def leer_simulacion(ruta):
    alfa, cl, estado = [], [], []
    with open(ruta, encoding="utf-8") as f:
        for linea in f:
            s = linea.strip()
            if not s or s.startswith("#"):
                continue
            c = s.replace(",", " ").split()
            try:
                a, l = float(c[0]), float(c[1])
            except (ValueError, IndexError):
                continue                      # línea con "sin resultados", etc.
            alfa.append(a)
            cl.append(l)
            estado.append(c[5] if len(c) > 5 else "ok")
    if not alfa:
        sys.exit(f"No se leyó ningún dato de {ruta}")
    return _ordenar(alfa, cl, estado)


def leer_experimento(ruta):
    alfa, cl, fuente = [], [], []
    with open(ruta, encoding="utf-8") as f:
        for linea in f:
            s = linea.strip()
            if not s:
                continue
            if s.startswith("#"):
                fuente.append(s.lstrip("# ").strip())
                continue
            c = s.replace(",", " ").split()
            try:
                alfa.append(float(c[0]))
                cl.append(float(c[1]))
            except (ValueError, IndexError):
                continue                      # encabezado de texto
    if not alfa:
        sys.exit(f"No se leyó ningún dato de {ruta}")
    a, c = _ordenar(alfa, cl)
    return a, c, fuente


# ----------------------------------------------------------------------------- numérica
def interp(x, xs, ys):
    """Interpolación lineal; xs creciente y x dentro de [xs[0], xs[-1]]."""
    for i in range(len(xs) - 1):
        if xs[i] <= x <= xs[i + 1]:
            if xs[i + 1] == xs[i]:
                return ys[i]
            return ys[i] + (ys[i + 1] - ys[i]) * (x - xs[i]) / (xs[i + 1] - xs[i])
    return ys[-1] if x == xs[-1] else float("nan")


def ajuste_lineal(alfa, cl, a_min, a_max):
    """Recta CL = k (alfa - alfa0) por mínimos cuadrados en [a_min, a_max]. Devuelve (k por grado, alfa0, n)."""
    pts = [(a, c) for a, c in zip(alfa, cl) if a_min <= a <= a_max]
    n = len(pts)
    if n < 2:
        return None
    mx = sum(p[0] for p in pts) / n
    my = sum(p[1] for p in pts) / n
    sxx = sum((p[0] - mx) ** 2 for p in pts)
    if sxx == 0:
        return None
    k = sum((p[0] - mx) * (p[1] - my) for p in pts) / sxx
    b = my - k * mx
    return k, -b / k, n


def alfa_l0_perfil_delgado(naca):
    """Ángulo de sustentación nula (grados) de la línea de curvatura NACA de 4 dígitos:
    alfa_L0 = -(1/pi) * integral_0^pi (dz/dx) (cos(theta) - 1) dtheta   (Anderson)."""
    m = int(naca[0]) / 100.0
    p = int(naca[1]) / 10.0
    if m == 0 or p == 0:
        return 0.0
    n = 20000
    h = math.pi / n
    suma = 0.0
    prev = None
    for i in range(n + 1):
        th = i * h
        x = 0.5 * (1.0 - math.cos(th))
        dz = 2 * m / p ** 2 * (p - x) if x < p else 2 * m / (1 - p) ** 2 * (p - x)
        f = dz * (math.cos(th) - 1.0)
        if prev is not None:
            suma += 0.5 * (f + prev) * h
        prev = f
    return math.degrees(-suma / math.pi)


# ----------------------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("simulacion")
    ap.add_argument("experimento")
    ap.add_argument("--naca", default="2415", help="código de 4 dígitos (para la teoría de perfil delgado)")
    ap.add_argument("--rango-lineal", nargs=2, type=float, default=[-4.0, 8.0], metavar=("AMIN", "AMAX"),
                    help="intervalo de alfa (grados) del tramo lineal; por omisión -4 8")
    ap.add_argument("--titulo", default="")
    ap.add_argument("--salida", default="comparacion_cl")
    ap.add_argument("--sin-grafica", action="store_true")
    ap.add_argument("--svg", action="store_true", help="forzar .svg aunque haya matplotlib")
    a = ap.parse_args()

    a_s, cl_s, est = leer_simulacion(a.simulacion)
    a_e, cl_e, fuente = leer_experimento(a.experimento)
    amin, amax = a.rango_lineal
    n = len(a_s)

    # --- tabla punto por punto (sólo donde hay dato experimental alrededor)
    dentro = [a_e[0] <= x <= a_e[-1] for x in a_s]
    cl_ex = [interp(x, a_e, cl_e) if d else float("nan") for x, d in zip(a_s, dentro)]
    dif = [cs - ce if d else float("nan") for cs, ce, d in zip(cl_s, cl_ex, dentro)]
    rel = [100 * df / ce if (d and abs(ce) > 0.05) else float("nan") for df, ce, d in zip(dif, cl_ex, dentro)]

    print("\n  alfa    CL_sim   CL_exp   dif     dif %   estado")
    for i in range(n):
        e = f"{cl_ex[i]:7.4f}" if dentro[i] else "   --  "
        d = f"{dif[i]:+7.4f}" if dentro[i] else "   --  "
        r = f"{rel[i]:+6.1f}" if dentro[i] and not math.isnan(rel[i]) else "  --  "
        print(f"{a_s[i]:6.1f}  {cl_s[i]:7.4f}  {e}  {d}  {r}   {est[i]}")

    with open(a.salida + ".csv", "w", encoding="utf-8") as f:
        f.write("alfa_deg,CL_sim,CL_exp_interpolado,diferencia,diferencia_pct,estado\n")
        for i in range(n):
            f.write(f"{a_s[i]:g},{cl_s[i]:.5f},"
                    f"{'' if not dentro[i] else format(cl_ex[i], '.5f')},"
                    f"{'' if not dentro[i] else format(dif[i], '.5f')},"
                    f"{'' if (not dentro[i] or math.isnan(rel[i])) else format(rel[i], '.2f')},{est[i]}\n")

    # --- métricas del tramo lineal
    print(f"\nTramo lineal: {amin:g}° a {amax:g}°")
    k_s = ajuste_lineal(a_s, cl_s, amin, amax)
    k_e = ajuste_lineal(a_e, cl_e, amin, amax)
    a0_teo = alfa_l0_perfil_delgado(a.naca)
    k_teo = 2 * math.pi * math.pi / 180.0                   # 2*pi por radián, por grado
    print(f"  Teoría de perfil delgado: pendiente {k_teo:.4f} /grado ({2 * math.pi:.3f} /rad), "
          f"alfa_L0 = {a0_teo:+.2f}°  (NACA {a.naca}, sólo curvatura)")
    for nombre, r in (("Simulación", k_s), ("Experimento", k_e)):
        if r is None:
            print(f"  {nombre}: menos de 2 puntos en el tramo; no se ajusta")
        else:
            k, a0, npts = r
            print(f"  {nombre}: pendiente {k:.4f} /grado ({k * 180 / math.pi:.3f} /rad), "
                  f"alfa_L0 = {a0:+.2f}°  ({npts} puntos)")
    if k_s and k_e:
        print(f"  Diferencia de pendiente sim-exp: {100 * (k_s[0] - k_e[0]) / k_e[0]:+.1f} %;  "
              f"alfa_L0 sim-exp: {k_s[1] - k_e[1]:+.2f}°")

    comunes = [dif[i] for i in range(n) if dentro[i] and amin <= a_s[i] <= amax]
    if comunes:
        rmse = math.sqrt(sum(d * d for d in comunes) / len(comunes))
        print(f"  Puntos comunes en el tramo: {len(comunes)};  error medio {sum(comunes) / len(comunes):+.4f}, "
              f"RMSE {rmse:.4f}, máximo |dif| {max(abs(d) for d in comunes):.4f}")

    # --- máximo observado
    i_s = max(range(n), key=lambda i: cl_s[i])
    i_e = max(range(len(cl_e)), key=lambda i: cl_e[i])
    print(f"\nCL máximo observado: simulación {cl_s[i_s]:.3f} en {a_s[i_s]:g}°;  "
          f"experimento {cl_e[i_e]:.3f} en {a_e[i_e]:g}°")
    if a_s[i_s] == max(a_s):
        print("  Aviso: el máximo de la simulación está en el último ángulo calculado; "
              "no se capturó la pérdida (no lo presente como CL,max).")
    malos = [f"{x:g}°" for x, s in zip(a_s, est) if s != "ok"]
    if malos:
        print("  Aviso: puntos de la simulación que no están 'ok' (no convergidos / oscilan): " + ", ".join(malos))
    if fuente:
        print("\nFuente de los datos experimentales (del encabezado del CSV):")
        for s in fuente:
            print("  " + s)

    # --- gráfica
    if a.sin_grafica:
        return
    plt = None
    if not a.svg:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            plt = None
    xs = [max(min(a_s[0], a_e[0]), amin - 2), min(max(a_s[-1], a_e[-1]), amax + 2)]
    ok = [e == "ok" for e in est]
    if plt is None:                                          # SVG con Python puro
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from svgplot import figura
        series = [{"x": a_e, "y": cl_e, "etiqueta": "Experimento", "estilo": "puntos", "hueco": True, "color": "#d62728"},
                  {"x": [x for x, o in zip(a_s, ok) if o], "y": [y for y, o in zip(cl_s, ok) if o],
                   "etiqueta": "OpenFOAM", "estilo": "ambos", "color": "#1f77b4"}]
        if not all(ok):
            series.append({"x": [x for x, o in zip(a_s, ok) if not o], "y": [y for y, o in zip(cl_s, ok) if not o],
                           "etiqueta": "OpenFOAM (no ok)", "estilo": "puntos", "color": "#888888"})
        series.append({"x": xs, "y": [k_teo * (v - a0_teo) for v in xs],
                       "etiqueta": f"Perfil delgado (alfa_L0 = {a0_teo:+.2f}°)", "discontinua": True, "color": "#666666"})
        figura(a.salida + ".svg", [{"titulo": a.titulo or f"NACA {a.naca}: CL contra alfa", "xlabel": "alfa (°)",
                                    "ylabel": "CL", "series": series, "lineas_h": [(0.0, "")]}],
               columnas=1, ancho_panel=720, alto_panel=480)
        print(f"\nEscribí {a.salida}.svg y {a.salida}.csv")
        return
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(a_e, cl_e, "s", mfc="none", color="tab:red", label="Experimento")
    ax.plot([x for x, o in zip(a_s, ok) if o], [y for y, o in zip(cl_s, ok) if o], "o-", color="tab:blue", label="OpenFOAM")
    if not all(ok):
        ax.plot([x for x, o in zip(a_s, ok) if not o], [y for y, o in zip(cl_s, ok) if not o], "x", color="tab:blue", ms=9,
                label="OpenFOAM (no 'ok')")
    ax.plot(xs, [k_teo * (v - a0_teo) for v in xs], "--", color="gray", lw=1,
            label=f"Perfil delgado (2π, αL0={a0_teo:+.2f}°)")
    ax.axhline(0, color="k", lw=0.5)
    ax.axvline(0, color="k", lw=0.5)
    ax.set_xlabel("Ángulo de ataque α (°)")
    ax.set_ylabel("$C_L$")
    ax.set_title(a.titulo or f"NACA {a.naca}: $C_L$ contra α")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(a.salida + ".png", dpi=150)
    print(f"\nEscribí {a.salida}.png y {a.salida}.csv")


if __name__ == "__main__":
    main()
