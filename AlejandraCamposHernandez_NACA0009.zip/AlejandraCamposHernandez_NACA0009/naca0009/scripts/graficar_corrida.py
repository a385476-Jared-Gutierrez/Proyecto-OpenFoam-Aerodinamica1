#!/usr/bin/env python3
"""
graficar_corrida.py -- historiales de residuales y de CL, CD y Cm de una o varias corridas.

Uso:
    python graficar_corrida.py casos/base_media/a0 [casos/base_media/a8 ...]
    python graficar_corrida.py casos/base_media            (todas las carpetas a<ángulo> del caso)

Escribe convergencia_a<alfa>.svg dentro de cada carpeta (ábralo con el navegador). Cuatro paneles:
    1. residuales iniciales de cada campo contra la iteración (escala logarítmica): el solver SIMPLE
       "converge" cuando bajan varios órdenes y se quedan planos;
    2-4. CL, CD y Cm(c/4, nariz arriba) contra la iteración, con la ventana final sombreada
       (la de los criterios de la hoja: 200 iteraciones) y la tolerancia pico a pico en el título.
No necesita matplotlib. La decisión de si convergió (ok / ~) la sigue tomando verificar.py; esto es para verla.
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verificar import ultimo, leer_columnas, serie, fuerzas, residuales      # noqa: E402
from cp_cf import leer_caso                                                    # noqa: E402
from svgplot import figura                                                     # noqa: E402


def graficar(carpeta, ventana):
    try:
        _, alfa = leer_caso(carpeta)
    except Exception:
        alfa = float(re.sub(r"^a", "", os.path.basename(carpeta)))
    rf = ultimo(os.path.join(carpeta, "postProcessing", "fuerzas", "*", "forceCoeffs.dat"))
    rr = ultimo(os.path.join(carpeta, "postProcessing", "residuales", "*", "residuals.dat"))
    if not rf:
        print(f"{carpeta}: no hay forceCoeffs.dat (¿ya corrió?)"); return
    nom, filas = leer_columnas(rf)
    t = serie(nom, filas, "Time")
    cl, cd = serie(nom, filas, "Cl"), serie(nom, filas, "Cd")
    cm = [-v for v in serie(nom, filas, "Cm")]                  # nariz arriba positivo
    w = min(ventana, len(t))
    banda = [(t[-w], t[-1])]
    fz = fuerzas(carpeta, ventana)

    paneles = []
    series_res = []
    if rr:
        nr, fr = leer_columnas(rr)
        for campo in nr[1:]:
            tt, vv = [], []
            for fila in fr:
                i = nr.index(campo)
                if len(fila) > i and fila[i] is not None and fila[i] > 0:
                    tt.append(fila[0]); vv.append(fila[i])
            if vv:
                series_res.append({"x": tt, "y": vv, "etiqueta": campo})
    ords = residuales(carpeta) or {}
    tit_res = "Residuales" + (f" (caída mínima {min(ords.values()):.1f} órdenes)" if ords else "")
    paneles.append({"titulo": tit_res, "xlabel": "iteración", "ylabel": "residual inicial", "logy": True,
                    "series": series_res, "bandas": banda, "leyenda": "derecha"})
    for nombre, y, clave in (("CL", cl, "CL"), ("CD", cd, "CD"), ("Cm (c/4, nariz arriba)", cm, "Cm")):
        tit = nombre
        if fz:
            tit += f": pico a pico {fz['ptp_' + clave]:.1e} (tol {fz['tol_' + clave]:.1e})"
        paneles.append({"titulo": tit, "xlabel": "iteración", "ylabel": nombre.split(" ")[0],
                        "series": [{"x": t, "y": y, "etiqueta": nombre}], "bandas": banda})
    salida = os.path.join(carpeta, f"convergencia_a{alfa:g}.svg")
    figura(salida, paneles, columnas=2)
    print(f"{carpeta}: escribí {salida}  (ventana sombreada: iteraciones {int(t[-w])} a {int(t[-1])})")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("carpetas", nargs="+")
    ap.add_argument("--ventana", type=int, default=200)
    a = ap.parse_args()
    todas = []
    for c in a.carpetas:
        c = c.rstrip("/\\")
        sub = sorted(d for d in os.listdir(c) if re.fullmatch(r"a-?\d+(\.\d+)?", d)) if os.path.isdir(c) else []
        if sub and not re.fullmatch(r"a-?\d+(\.\d+)?", os.path.basename(c)):
            todas += [os.path.join(c, d) for d in sub]
        else:
            todas.append(c)
    for c in todas:
        graficar(c, a.ventana)


if __name__ == "__main__":
    main()
