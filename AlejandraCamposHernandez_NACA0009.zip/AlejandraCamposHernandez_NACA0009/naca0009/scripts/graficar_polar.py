#!/usr/bin/env python3
"""
graficar_polar.py -- resultados del barrido de ángulos (sección 7 de la hoja del proyecto) y y+(x/c).

Uso:
    python graficar_polar.py casos/base_media                                  una malla: tabla, curvas y métricas
    python graficar_polar.py casos/base_media casos/val_Re6e6                  varias en la misma figura
    python graficar_polar.py casos/base_media --yplus casos/base_media/a0 casos/base_media/a8 casos/base_media/a16
    python graficar_polar.py --yplus casos/base_media/a16                      sólo y+

Cada caso es una carpeta con polar.dat (lo escribe Allpolar / verificar.py). Con casos escribe, con el prefijo
--salida (por omisión <caso>/polar para uno solo, o ./polar_comparacion para varios):
    <prefijo>.svg       cinco paneles: cl(alfa), cd(alfa), cm(c/4)(alfa), polar cd contra cl, eficiencia cl/cd contra alfa
    tabla_polar.csv     alfa, cl, cd, cm, cl/cd, estado, malla, celdas y las cargas por unidad de claro (L', D', M') y
                        sobre el claro b de la extrusión (L, D, M), en unidades del SI
y en pantalla: la tabla, la pendiente de levante (por grado y por radián), el ángulo de levante nulo, la máxima
eficiencia con su ángulo y el cl máximo observado. Los puntos que no están 'ok' se dibujan huecos y se excluyen del
ajuste y de la eficiencia máxima (si no hay ninguno 'ok', se usan todos y se avisa).

Cargas: el solucionador es cinemático y forceCoeffs usa Aref = c*b, lref = c, así que
    q = 0.5 rho U^2,   L' = cl q c,   D' = cd q c,   M' = cm q c^2   (por unidad de claro; N/m, N/m y N m/m)
    L = L' b,   D = D' b,   M = M' b                                   (sobre el claro b de la extrusión; N, N, N m)
con rho = 1.225 kg/m3 (el de la hoja; --rho para otro), c = 1 m (--cuerda), b = 0.01 m (--b). U se lee de
system/controlDict de las carpetas a<ángulo> del caso (--U fuerza otro valor).

y+(x/c): para cada carpeta de ángulo de --yplus lee postProcessing/pared/<iteración>/*.xy (x y z p tau y+...) y escribe
yplus_a<alfa>.svg; imprime mínimo, máximo, promedio ponderado por longitud de cara y % de la superficie con
y+ <= --pared (2), por superficie y total.

Sólo usa la biblioteca estándar de Python.
"""
import argparse
import glob
import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from svgplot import figura, COLORES                                            # noqa: E402
from comparar_cl import ajuste_lineal, alfa_l0_perfil_delgado                  # noqa: E402
from cp_cf import leer_xy, ordenar, ultimo, leer_caso                          # noqa: E402


# ----------------------------------------------------------------------------- lectura
def leer_polar(caso):
    ruta = os.path.join(caso, "polar.dat")
    if not os.path.exists(ruta):
        sys.exit(f"No hay {ruta}: corra Allpolar (o scripts/verificar.py {caso}) primero")
    filas = []
    with open(ruta, encoding="utf-8") as f:
        for linea in f:
            s = linea.strip()
            if not s or s.startswith("#"):
                continue
            c = s.split()
            try:
                filas.append({"alfa": float(c[0]), "cl": float(c[1]), "cd": float(c[2]), "cm": float(c[3]),
                              "it": int(float(c[4])) if len(c) > 4 else 0, "estado": c[5] if len(c) > 5 else "ok"})
            except (ValueError, IndexError):
                continue
    if not filas:
        sys.exit(f"{ruta} no tiene datos")
    return sorted(filas, key=lambda r: r["alfa"])


def velocidad_del_caso(caso):
    for ruta in sorted(glob.glob(os.path.join(caso, "a*", "system", "controlDict"))):
        with open(ruta, encoding="utf-8") as f:
            m = re.search(r"magUInf=([0-9.eE+-]+)", f.read())
        if m:
            return float(m.group(1))
    ruta = os.path.join(caso, "log.parametros")
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            m = re.search(r"Uinf ([0-9.eE+-]+)", f.read())
        if m:
            return float(m.group(1))
    return None


def celdas_del_caso(caso):
    for nombre in ("log.checkMesh_basico", "log.checkMesh"):
        ruta = os.path.join(caso, nombre)
        if os.path.exists(ruta):
            with open(ruta, encoding="utf-8", errors="replace") as f:
                m = re.search(r"^\s*cells:\s+(\d+)", f.read(), re.M)
            if m:
                return int(m.group(1))
    return None


def naca_del_caso(caso):
    ruta = os.path.join(caso, "log.parametros")
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            m = re.search(r"NACA (\d+)", f.read())
        if m:
            return m.group(1).zfill(4)
    return None


# ----------------------------------------------------------------------------- polar
def tabla(caso, nombre, U, rho, c, b):
    filas = leer_polar(caso)
    q = 0.5 * rho * U * U
    nc = celdas_del_caso(caso)
    for r in filas:
        r["eff"] = r["cl"] / r["cd"] if r["cd"] else float("nan")
        r["Lp"], r["Dp"], r["Mp"] = r["cl"] * q * c, r["cd"] * q * c, r["cm"] * q * c * c
        r["L"], r["D"], r["M"] = r["Lp"] * b, r["Dp"] * b, r["Mp"] * b
        r["malla"], r["celdas"], r["U"], r["q"] = nombre, nc, U, q
    return filas


def imprimir(nombre, filas, U, q, args, naca):
    print(f"\n=== {nombre}: U = {U:g} m/s, q = 0.5 rho U^2 = {q:.2f} Pa (rho = {args.rho:g} kg/m3, c = {args.cuerda:g} m, b = {args.b:g} m)"
          + (f", {filas[0]['celdas']} celdas" if filas[0]["celdas"] else ""))
    print("  alfa      cl        cd     cm(c/4)   cl/cd    estado     L'(N/m)    D'(N/m)   M'(N m/m)     L(N)       D(N)      M(N m)")
    for r in filas:
        print(f"{r['alfa']:6g} {r['cl']:9.5f} {r['cd']:9.6f} {r['cm']:9.5f} {r['eff']:8.2f}    {r['estado']:6s} "
              f"{r['Lp']:10.2f} {r['Dp']:10.3f} {r['Mp']:10.2f} {r['L']:10.4f} {r['D']:10.5f} {r['M']:10.5f}")
    ok = [r for r in filas if r["estado"] == "ok"]
    base = ok if len(ok) >= 2 else filas
    if len(ok) < 2:
        print("  Aviso: menos de dos puntos 'ok'; las métricas usan todos los puntos")
    amin, amax = args.rango_lineal
    aj = ajuste_lineal([r["alfa"] for r in base], [r["cl"] for r in base], amin, amax)
    print(f"  Tramo lineal {amin:g}° a {amax:g}°:", end=" ")
    if aj:
        k, a0, n = aj
        print(f"pendiente {k:.4f} /grado ({k * 180 / math.pi:.3f} /rad; teoría 2π = 6.283 /rad), alfa de levante nulo {a0:+.2f}° ({n} puntos)")
    else:
        print("menos de dos puntos, sin ajuste")
    if naca:
        print(f"  Perfil delgado (curvatura del NACA {naca}): alfa_L0 = {alfa_l0_perfil_delgado(naca):+.2f}°")
    ie = max(range(len(base)), key=lambda i: base[i]["eff"] if base[i]["eff"] == base[i]["eff"] else -1e9)
    print(f"  Máxima eficiencia: cl/cd = {base[ie]['eff']:.2f} a alfa = {base[ie]['alfa']:g}° (cl = {base[ie]['cl']:.3f}, cd = {base[ie]['cd']:.5f})"
          + ("  <- en el extremo del intervalo: puede haber una mayor fuera" if base[ie] in (base[0], base[-1]) else ""))
    im = max(range(len(filas)), key=lambda i: filas[i]["cl"])
    print(f"  cl máximo observado: {filas[im]['cl']:.3f} a alfa = {filas[im]['alfa']:g}° (estado {filas[im]['estado']})"
          + ("  <- es el último ángulo calculado: no se capturó la pérdida" if filas[im] is filas[-1] else ""))
    malos = [f"{r['alfa']:g}°" for r in filas if r["estado"] != "ok"]
    if malos:
        print("  No 'ok' (convergido): " + ", ".join(malos) + ": clasifíquelos como promedio de ventana o no resuelto en el reporte")


def series(todos, kx, ky):
    out = []
    for i, (nombre, filas) in enumerate(todos):
        col = COLORES[i % len(COLORES)]
        ok = [r for r in filas if r["estado"] == "ok"]
        mal = [r for r in filas if r["estado"] != "ok"]
        out.append({"x": [r[kx] for r in ok], "y": [r[ky] for r in ok], "etiqueta": nombre, "estilo": "ambos", "color": col})
        if mal:
            out.append({"x": [r[kx] for r in mal], "y": [r[ky] for r in mal], "etiqueta": f"{nombre} (no ok)",
                        "estilo": "puntos", "hueco": True, "color": col})
    return out


def figura_polar(ruta, todos):
    pan = lambda tit, xl, yl, kx, ky, extra=None: dict(
        {"titulo": tit, "xlabel": xl, "ylabel": yl, "series": series(todos, kx, ky)}, **(extra or {}))
    paneles = [
        pan("cl contra alfa", "alfa (°)", "cl", "alfa", "cl", {"lineas_h": [(0.0, "")], "leyenda_siempre": len(todos) > 1}),
        pan("cd contra alfa", "alfa (°)", "cd", "alfa", "cd"),
        pan("cm(c/4) contra alfa (nariz arriba positivo)", "alfa (°)", "cm", "alfa", "cm", {"lineas_h": [(0.0, "")]}),
        pan("Polar: cd contra cl", "cl", "cd", "cl", "cd"),
        pan("Eficiencia cl/cd contra alfa", "alfa (°)", "cl/cd", "alfa", "eff", {"lineas_h": [(0.0, "")]}),
    ]
    figura(ruta, paneles, columnas=3, ancho_panel=470, alto_panel=330)


def escribir_tabla(ruta, todos):
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("malla,celdas,U_ms,q_Pa,alfa_deg,cl,cd,cm_c4,cl_cd,estado,Lp_N_m,Dp_N_m,Mp_Nm_m,L_N,D_N,M_Nm\n")
        for nombre, filas in todos:
            for r in filas:
                f.write(f"{nombre},{r['celdas'] if r['celdas'] else ''},{r['U']:g},{r['q']:.4f},{r['alfa']:g},"
                        f"{r['cl']:.5f},{r['cd']:.6f},{r['cm']:.5f},{r['eff']:.3f},{r['estado']},"
                        f"{r['Lp']:.4f},{r['Dp']:.5f},{r['Mp']:.4f},{r['L']:.6f},{r['D']:.7f},{r['M']:.7f}\n")


# ----------------------------------------------------------------------------- y+
def pesos(seg):
    n = len(seg)
    w = []
    for i in range(n):
        d = []
        if i > 0:
            d.append(math.hypot(seg[i][0] - seg[i - 1][0], seg[i][1] - seg[i - 1][1]))
        if i < n - 1:
            d.append(math.hypot(seg[i + 1][0] - seg[i][0], seg[i + 1][1] - seg[i][1]))
        w.append(sum(d) / len(d) if d else 0.0)
    return w


def estadisticas(nombre, seg, umbral):
    w, yp = pesos(seg), [p[7] for p in seg]
    W = sum(w)
    print(f"    {nombre:9s} {len(seg):4d} caras: y+ mín {min(yp):.3f}, máx {max(yp):.3f}, "
          f"promedio ponderado {sum(a * b for a, b in zip(yp, w)) / W:.3f}, {100 * sum(a for a, b in zip(w, yp) if b <= umbral) / W:.1f} % con y+ <= {umbral:g}")
    return w, yp


def grafica_yplus(carpeta, c, umbral):
    ruta = ultimo(os.path.join(carpeta, "postProcessing", "pared", "*", "*.xy"))
    if not ruta:
        print(f"{carpeta}: no hay postProcessing/pared/*/*.xy"); return
    pts = leer_xy(ruta)
    if not pts:
        print(f"{carpeta}: {ruta} no tiene filas de 8 columnas (x y z p tau_x tau_y tau_z y+)"); return
    try:
        _, alfa = leer_caso(carpeta)
    except Exception:
        alfa = float(re.sub(r"^a", "", os.path.basename(carpeta)))
    ex, inn, ciclo = ordenar(pts)
    print(f"\n=== y+ en {carpeta} (alfa = {alfa:g}°, {len(pts)} caras)")
    estadisticas("extradós", ex, umbral)
    estadisticas("intradós", inn, umbral)
    # total: sobre el contorno completo, para no contar dos veces las caras de los bordes de ataque y de salida
    n = len(ciclo)
    w = [0.5 * (math.hypot(ciclo[i][0] - ciclo[i - 1][0], ciclo[i][1] - ciclo[i - 1][1]) +
                math.hypot(ciclo[(i + 1) % n][0] - ciclo[i][0], ciclo[(i + 1) % n][1] - ciclo[i][1])) for i in range(n)]
    yp = [p[7] for p in ciclo]
    print(f"    total      {len(yp):4d} caras: y+ mín {min(yp):.3f}, máx {max(yp):.3f}, "
          f"promedio ponderado {sum(a * b for a, b in zip(yp, w)) / sum(w):.3f}, {100 * sum(a for a, b in zip(w, yp) if b <= umbral) / sum(w):.1f} % con y+ <= {umbral:g}")
    salida = os.path.join(carpeta, f"yplus_a{alfa:g}.svg")
    figura(salida, [{"titulo": f"y+ sobre el perfil, alfa = {alfa:g}°", "xlabel": "x/c", "ylabel": "y+",
                     "series": [{"x": [p[0] / c for p in ex], "y": [p[7] for p in ex], "etiqueta": "extradós"},
                                {"x": [p[0] / c for p in inn], "y": [p[7] for p in inn], "etiqueta": "intradós"}],
                     "lineas_h": [(1.0, "y+ = 1"), (umbral, f"y+ = {umbral:g}")]}], columnas=1, ancho_panel=760, alto_panel=420)
    print(f"    escribí {salida}")


# ----------------------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("casos", nargs="*", help="carpetas de caso con polar.dat")
    ap.add_argument("--yplus", nargs="*", default=[], metavar="CARPETA_ANGULO")
    ap.add_argument("--rango-lineal", nargs=2, type=float, default=[-4.0, 8.0], metavar=("AMIN", "AMAX"))
    ap.add_argument("--rho", type=float, default=1.225)
    ap.add_argument("--cuerda", type=float, default=1.0)
    ap.add_argument("--b", type=float, default=0.01, help="claro de la extrusión en z (m)")
    ap.add_argument("--U", type=float, default=None)
    ap.add_argument("--naca", default=None, help="código de 4 dígitos para la teoría de perfil delgado (si no, se lee del caso)")
    ap.add_argument("--pared", type=float, default=2.0)
    ap.add_argument("--salida", default=None)
    a = ap.parse_args()
    if not a.casos and not a.yplus:
        ap.error("indique al menos un caso o --yplus")

    todos = []
    for c in a.casos:
        c = c.rstrip("/\\")
        U = a.U or velocidad_del_caso(c)
        if U is None:
            sys.exit(f"No pude leer U de {c}: use --U")
        filas = tabla(c, os.path.basename(c), U, a.rho, a.cuerda, a.b)
        imprimir(os.path.basename(c), filas, U, filas[0]["q"], a, a.naca or naca_del_caso(c))
        todos.append((os.path.basename(c), filas))
    if todos:
        pref = a.salida or (os.path.join(a.casos[0].rstrip("/\\"), "polar") if len(todos) == 1 else "polar_comparacion")
        figura_polar(pref + ".svg", todos)
        ruta_tabla = os.path.join(os.path.dirname(pref) or ".", "tabla_polar.csv") if len(todos) == 1 else pref + "_tabla.csv"
        escribir_tabla(ruta_tabla, todos)
        print(f"\nEscribí {pref}.svg y {ruta_tabla}")
    for d in a.yplus:
        grafica_yplus(d.rstrip("/\\"), a.cuerda, a.pared)


if __name__ == "__main__":
    main()
