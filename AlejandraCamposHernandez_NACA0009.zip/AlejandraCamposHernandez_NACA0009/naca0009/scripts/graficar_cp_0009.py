
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# Carpeta principal del proyecto
BASE = Path(__file__).resolve().parent.parent
CASOS = BASE / "casos"
SALIDA = BASE / "imagenes_0009"
SALIDA.mkdir(exist_ok=True)

def cargar_csv(ruta):
    df = pd.read_csv(ruta)
    requeridas = {"superficie", "x_c", "cp"}
    if not requeridas.issubset(df.columns):
        raise ValueError(f"Faltan columnas en {ruta}")

    df["x_c"] = pd.to_numeric(df["x_c"])
    df["cp"] = pd.to_numeric(df["cp"])
    return df

def graficar_curvas(series, titulo, archivo):
    fig, ax = plt.subplots(figsize=(9, 6))

    estilos = {
        "extrados": "-",
        "intrados": "--"
    }

    for etiqueta, ruta in series:
        df = cargar_csv(ruta)

        for superficie in ["extrados", "intrados"]:
            datos = df[df["superficie"].str.lower() == superficie]
            datos = datos.sort_values("x_c")

            if datos.empty:
                continue

            ax.plot(
                datos["x_c"],
                datos["cp"],
                linestyle=estilos[superficie],
                linewidth=1.7,
                label=f"{etiqueta} - {superficie}"
            )

    ax.set_xlabel("Posición relativa, x/c", fontsize=11)
    ax.set_ylabel("Coeficiente de presión, Cp", fontsize=11)
    ax.set_title(titulo, fontsize=13, weight="bold")

    # Convención aerodinámica: Cp negativo hacia arriba
    ax.invert_yaxis()

    ax.set_xlim(0, 1)
    ax.grid(True, linestyle=":", alpha=0.65)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()

    destino = SALIDA / archivo
    fig.savefig(destino, format="pdf", bbox_inches="tight")
    plt.close(fig)

    print(f"Figura guardada: {destino}")

# 1. Comparación de mallas a 8 grados
mallas = [
    ("Malla gruesa", CASOS / "n0009_base_gruesa/a8/cp_cf_a8.csv"),
    ("Malla media", CASOS / "n0009_base_media/a8/cp_cf_a8.csv"),
    ("Malla fina", CASOS / "n0009_base_fina/a8/cp_cf_a8.csv"),
]

graficar_curvas(
    mallas,
    "Distribución de Cp - Independencia de malla (8°)",
    "n0009_cp_mallas_a8.pdf"
)

# 2. Comparación entre 0 y 8 grados
angulos_0_8 = [
    ("0°", CASOS / "n0009_base_media/a0/cp_cf_a0.csv"),
    ("8°", CASOS / "n0009_base_media/a8/cp_cf_a8.csv"),
]

graficar_curvas(
    angulos_0_8,
    "Distribución de Cp - Comparación de ángulos",
    "n0009_cp_a0_a8.pdf"
)

# 3. Comparación entre 0, 8 y 16 grados
angulos_3 = [
    ("0°", CASOS / "n0009_base_media/a0/cp_cf_a0.csv"),
    ("8°", CASOS / "n0009_base_media/a8/cp_cf_a8.csv"),
    ("16°", CASOS / "n0009_base_media/a16/cp_cf_a16.csv"),
]

graficar_curvas(
    angulos_3,
    "Distribución de Cp - Comparación de tres ángulos",
    "n0009_cp_tres_angulos.pdf"
)

print("\nProceso terminado. Se generaron las tres figuras.")
