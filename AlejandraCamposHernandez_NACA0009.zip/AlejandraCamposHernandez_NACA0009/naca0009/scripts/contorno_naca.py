#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Contorno de un perfil NACA de cuatro digitos: genera un SVG (para el reporte) y un CSV con las coordenadas.
Python puro: no necesita numpy ni matplotlib.

Uso (desde la carpeta NACA0009):
    python3 scripts/contorno_naca.py 0009
    python3 scripts/contorno_naca.py 0009 --salida casos/n0009_base_media/contorno_0009
    python3 scripts/contorno_naca.py 2412 --abierto        (borde de salida abierto, coef. -0.1015)

Convencion: cuerda c = 1 sobre +x, borde de ataque en (0, 0), +y hacia el extrados.
Por omision el borde de salida es CERRADO (coeficiente -0.1036), que es el que se declara en el reporte.
Distribucion de puntos tipo coseno: x = 0.5 (1 - cos beta), para concentrar puntos en los bordes.
"""
import argparse
import csv
import math


def naca4(codigo, n=100, abierto=False):
    """Devuelve (xs, ys, xu, yu, xl, yl, m, p, t) del perfil. Contorno de TE -> extrados -> LE -> intrados -> TE."""
    codigo = str(codigo).zfill(4)
    if len(codigo) != 4 or not codigo.isdigit():
        raise SystemExit("El codigo debe tener cuatro digitos, por ejemplo 0009 o 2412")
    m = int(codigo[0]) / 100.0       # combadura maxima
    p = int(codigo[1]) / 10.0        # posicion de la combadura maxima
    t = int(codigo[2:]) / 100.0      # espesor maximo
    a4 = -0.1015 if abierto else -0.1036

    xu, yu, xl, yl = [], [], [], []
    for i in range(n + 1):
        beta = math.pi * i / n
        x = 0.5 * (1.0 - math.cos(beta))
        yt = 5.0 * t * (0.2969 * math.sqrt(x) - 0.1260 * x - 0.3516 * x ** 2 + 0.2843 * x ** 3 + a4 * x ** 4)
        if m == 0 or p == 0:
            yc, dyc = 0.0, 0.0
        elif x < p:
            yc = m / p ** 2 * (2 * p * x - x ** 2)
            dyc = 2 * m / p ** 2 * (p - x)
        else:
            yc = m / (1 - p) ** 2 * ((1 - 2 * p) + 2 * p * x - x ** 2)
            dyc = 2 * m / (1 - p) ** 2 * (p - x)
        th = math.atan(dyc)
        xu.append(x - yt * math.sin(th)); yu.append(yc + yt * math.cos(th))
        xl.append(x + yt * math.sin(th)); yl.append(yc - yt * math.cos(th))

    # Contorno cerrado: borde de salida -> extrados -> borde de ataque -> intrados -> borde de salida
    xs = xu[::-1] + xl[1:]
    ys = yu[::-1] + yl[1:]
    return xs, ys, xu, yu, xl, yl, m, p, t


def escribir_csv(ruta, xu, yu, xl, yl):
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        # los puntos x del extrados e intrados difieren si hay combadura: se guardan ambos
        w.writerow(["superficie", "x/c", "y/c"])
        for x, y in zip(xu, yu):
            w.writerow(["extrados", "%.6f" % x, "%.6f" % y])
        for x, y in zip(xl, yl):
            w.writerow(["intrados", "%.6f" % x, "%.6f" % y])


def escribir_svg(ruta, xs, ys, xu, yu, xl, yl, codigo, m, p, t, n_puntos):
    ancho, alto = 900, 420
    mx, my = 60, 60
    escala = ancho - 2 * mx                     # x en [0, 1] -> pixeles
    ymax = max(ys) if max(ys) > 0 else 0.1
    ymin = min(ys)
    y0 = alto / 2 + (ymax + ymin) / 2 * escala  # centra el perfil verticalmente

    def X(x): return mx + x * escala
    def Y(y): return y0 - y * escala

    pts = " ".join("%.2f,%.2f" % (X(x), Y(y)) for x, y in zip(xs, ys))
    s = []
    s.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" font-family="sans-serif">'
             % (ancho, alto, ancho, alto))
    s.append('<rect width="100%" height="100%" fill="white"/>')
    # rejilla y ejes
    for k in range(0, 11):
        xk = k / 10.0
        s.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#e5e5e5"/>' % (X(xk), 70, X(xk), alto - 50))
        s.append('<text x="%.2f" y="%d" font-size="12" text-anchor="middle" fill="#444">%.1f</text>' % (X(xk), alto - 30, xk))
    s.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#999" stroke-dasharray="6,4"/>'
             % (X(0), Y(0), X(1), Y(0)))
    # contorno
    s.append('<polygon points="%s" fill="#cfe3f5" stroke="#1f4e79" stroke-width="2" stroke-linejoin="round"/>' % pts)
    # puntos
    for x, y in zip(xs, ys):
        s.append('<circle cx="%.2f" cy="%.2f" r="1.6" fill="#1f4e79"/>' % (X(x), Y(y)))
    # linea de combadura (si hay)
    if m > 0:
        cam = []
        for i in range(len(xu)):
            cam.append("%.2f,%.2f" % (X((xu[i] + xl[i]) / 2), Y((yu[i] + yl[i]) / 2)))
        s.append('<polyline points="%s" fill="none" stroke="#c0392b" stroke-width="1.2" stroke-dasharray="4,3"/>' % " ".join(cam))
    # etiquetas
    s.append('<text x="%d" y="30" font-size="18" font-weight="bold" fill="#222">NACA %s</text>' % (mx, codigo))
    s.append('<text x="%d" y="48" font-size="12" fill="#444">combadura m = %.0f%% c, posicion p = %.0f%% c, '
             'espesor t = %.0f%% c; c = 1, borde de ataque en (0, 0); %d puntos</text>'
             % (mx, m * 100, p * 100, t * 100, n_puntos))
    s.append('<text x="%.2f" y="%d" font-size="12" text-anchor="middle" fill="#444">x/c</text>' % (X(0.5), alto - 10))
    s.append('</svg>')
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(s))


def main():
    ap = argparse.ArgumentParser(description="Contorno de un NACA de cuatro digitos (SVG + CSV)")
    ap.add_argument("codigo", help="codigo de cuatro digitos, por ejemplo 0009")
    ap.add_argument("--n", type=int, default=100, help="puntos por superficie (100 por omision)")
    ap.add_argument("--abierto", action="store_true", help="borde de salida abierto (-0.1015); por omision cerrado (-0.1036)")
    ap.add_argument("--salida", default=None, help="prefijo de salida (por omision contorno_NACAxxxx)")
    a = ap.parse_args()

    codigo = str(a.codigo).zfill(4)
    xs, ys, xu, yu, xl, yl, m, p, t = naca4(codigo, a.n, a.abierto)
    base = a.salida or "contorno_NACA%s" % codigo
    escribir_svg(base + ".svg", xs, ys, xu, yu, xl, yl, codigo, m, p, t, len(xs))
    escribir_csv(base + ".csv", xu, yu, xl, yl)

    # comprobaciones para el reporte
    ymax = max(yu[i] - yl[i] for i in range(len(xu)))
    ix = max(range(len(xu)), key=lambda i: yu[i] - yl[i])
    print("NACA %s: m = %.2f, p = %.1f, t = %.2f" % (codigo, m, p, t))
    print("Espesor maximo = %.4f c en x/c = %.3f" % (ymax, xu[ix]))
    print("Espesor en el borde de salida = %.6f c (%s)" % (yu[0] - yl[0], "abierto" if a.abierto else "cerrado"))
    print("Escribi %s.svg y %s.csv" % (base, base))


if __name__ == "__main__":
    main()
