#!/usr/bin/env python3
"""
estudio_malla.py -- diferencias entre las tres mallas con las metas de la hoja del proyecto.

Uso:  python estudio_malla.py casos/base_gruesa casos/base_media casos/base_fina [--alfas 0 8]

Lee polar.dat de cada carpeta (lo escribe Allpolar/verificar.py) y, para cada ángulo, tabula CL, CD y Cm,
las diferencias gruesa-media y media-fina, y si la diferencia media-fina cumple la meta:
    dCL <= max(0.02 |CL_f|, 0.002)     dCD <= max(0.05 |CD_f|, 0.0002)     dCm <= max(0.03 |Cm_f|, 0.001)
Son metas didácticas, no una cota del error. Sólo compara puntos con estado 'ok' en las tres mallas;
los demás se marcan: no se compara una solución sin convergir.
"""
import argparse, os, sys


def leer(carpeta):
    d = {}
    with open(os.path.join(carpeta, "polar.dat"), encoding="utf-8") as f:
        for l in f:
            if l.startswith("#") or not l.strip():
                continue
            c = l.split()
            d[float(c[0])] = (float(c[1]), float(c[2]), float(c[3]), c[5] if len(c) > 5 else "ok")
    return d


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("gruesa"); ap.add_argument("media"); ap.add_argument("fina")
    ap.add_argument("--alfas", nargs="*", type=float)
    a = ap.parse_args()
    g, m, f = leer(a.gruesa), leer(a.media), leer(a.fina)
    alfas = a.alfas if a.alfas else sorted(set(g) & set(m) & set(f))
    metas = [("CL", 0, 0.02, 0.002), ("CD", 1, 0.05, 0.0002), ("Cm", 2, 0.03, 0.001)]
    print("alfa  coef   gruesa     media      fina     |g-m|     |m-f|    meta(m-f)  cumple   estados")
    for al in alfas:
        if not (al in g and al in m and al in f):
            print(f"{al:5g}  falta en alguna malla"); continue
        est = "/".join(x[al][3] for x in (g, m, f))
        for nombre, i, rel, ab in metas:
            cg, cm_, cf = g[al][i], m[al][i], f[al][i]
            meta = max(rel * abs(cf), ab)
            dgm, dmf = abs(cm_ - cg), abs(cf - cm_)
            cumple = "sí" if dmf <= meta else "NO"
            if est != "ok/ok/ok":
                cumple += " (sin comparar: no todas ok)"
            print(f"{al:5g}  {nombre:4s} {cg:9.5f} {cm_:9.5f} {cf:9.5f} {dgm:9.5f} {dmf:9.5f} {meta:9.5f}  {cumple:8s} {est}")


if __name__ == "__main__":
    main()
