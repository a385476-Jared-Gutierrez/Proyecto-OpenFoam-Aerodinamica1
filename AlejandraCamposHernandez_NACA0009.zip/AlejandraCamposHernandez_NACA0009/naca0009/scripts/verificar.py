#!/usr/bin/env python3
"""
verificar.py -- convergencia, balance de flujo y y+ de las corridas de una polar, y la tabla polar.dat.

Uso:
    python verificar.py CASO [alfa ...]        CASO = carpeta con las subcarpetas a<alfa> que crea Allpolar
                                                (sin ángulos: las detecta todas)
Opciones:
    --ventana N      iteraciones de la ventana final (200, como pide la hoja del proyecto)
    --pared Y        umbral de y+ para el porcentaje de superficie (2)

Criterios (hoja del proyecto, caso estacionario), todos medidos en la ventana final:
    cl, cm:  variación pico a pico < max(0.01 |c|, 1e-3)
    cd:      variación pico a pico < max(0.01 |cd|, 1e-4)
    tendencia: la diferencia entre la media de la primera y la de la segunda mitad de la ventana, con la misma tolerancia
    residuales: reducción de al menos 3 órdenes (residual inicial de la primera iteración contra el de la última)
    balance:  |suma de los flujos| / (suma de los flujos entrantes) < 0.5 %, con flujo saliente positivo

Escribe en CASO:  polar.dat (alfa CL CD Cm iteraciones estado) y verificacion.csv (todas las métricas).
polar.dat es lo que lee comparar_cl.py. Cm sale con la nariz arriba positivo (el archivo de OpenFOAM, con
pitchAxis = (0 0 1), da el signo contrario). 'estado' es 'ok' sólo si pasan todos los criterios; si no, '~'
(en verificacion.csv está cuál falló). Un '~' no es un error del script: es un caso que no cumple lo pedido.
"""
import argparse
import glob
import math
import os
import re
import sys


# ----------------------------------------------------------------------------- lectura
def ultimo(patron):
    """Último archivo que cumple el patrón, ordenado por el número de la carpeta que lo contiene."""
    rutas = glob.glob(patron)
    if not rutas:
        return None
    def clave(r):
        m = re.search(r"/(\d+(?:\.\d+)?)/[^/]*$", r.replace("\\", "/"))
        return float(m.group(1)) if m else -1.0
    return sorted(rutas, key=clave)[-1]


def leer_columnas(ruta):
    """Archivo de función de OpenFOAM: devuelve (nombres, filas). Los N/A quedan como None."""
    nombres, filas = None, []
    with open(ruta, encoding="utf-8", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if not s:
                continue
            if s.startswith("#"):
                cuerpo = s.lstrip("# ").strip()
                if cuerpo.startswith("Time"):
                    nombres = cuerpo.split()
                continue
            fila = []
            for c in s.split():
                try:
                    fila.append(float(c))
                except ValueError:
                    fila.append(None)
            filas.append(fila)
    return nombres, filas


def serie(nombres, filas, col):
    i = nombres.index(col)
    return [r[i] for r in filas if len(r) > i and r[i] is not None]


def ppt(x):
    return max(x) - min(x)


def tol(valor, rel, absoluta):
    return max(rel * abs(valor), absoluta)


# ----------------------------------------------------------------------------- fuerzas
def fuerzas(caso_a, ventana):
    ruta = ultimo(os.path.join(caso_a, "postProcessing", "fuerzas", "*", "forceCoeffs.dat"))
    if not ruta:
        return None
    nom, filas = leer_columnas(ruta)
    if not nom or not filas:
        return None
    t = serie(nom, filas, "Time")
    cm, cd, cl = (serie(nom, filas, k) for k in ("Cm", "Cd", "Cl"))
    n = len(t)
    w = min(ventana, n)
    r = {"iter": int(t[-1]), "n": n, "ventana": w}
    # valores finales: promedio de las dos últimas iteraciones (CD y Cm alternan entre dos valores, tutorial 2.1)
    r["CL"] = (cl[-1] + cl[-2]) / 2 if n > 1 else cl[-1]
    r["CD"] = (cd[-1] + cd[-2]) / 2 if n > 1 else cd[-1]
    r["Cm"] = -((cm[-1] + cm[-2]) / 2 if n > 1 else cm[-1])        # nariz arriba positivo
    for nombre, x, rel, ab in (("CL", cl, 0.01, 1e-3), ("Cm", [-v for v in cm], 0.01, 1e-3), ("CD", cd, 0.01, 1e-4)):
        v = x[-w:]
        h = len(v) // 2
        media = sum(v) / len(v)
        r[f"ptp_{nombre}"] = ppt(v)
        r[f"tol_{nombre}"] = tol(media, rel, ab)
        r[f"tend_{nombre}"] = (sum(v[h:]) / len(v[h:]) - sum(v[:h]) / max(h, 1)) if h else 0.0
        r[f"ok_{nombre}"] = ppt(v) < r[f"tol_{nombre}"] and abs(r[f"tend_{nombre}"]) < r[f"tol_{nombre}"]
    return r


# ----------------------------------------------------------------------------- residuales
def residuales(caso_a):
    ruta = ultimo(os.path.join(caso_a, "postProcessing", "residuales", "*", "residuals.dat"))
    if not ruta:
        return None
    nom, filas = leer_columnas(ruta)
    if not nom:
        return None
    ordenes = {}
    for campo in nom[1:]:
        x = [v for v in serie(nom, filas, campo) if v and v > 0]
        if len(x) > 1:
            ordenes[campo] = math.log10(x[0] / x[-1])
    return ordenes or None


# ----------------------------------------------------------------------------- balance de flujo
def _valores_parche(texto, parche):
    m = re.search(r"\b" + re.escape(parche) + r"\s*\{(.*?)\n\s*\}", texto, re.S)
    if not m:
        return None
    b = m.group(1)
    mu = re.search(r"value\s+uniform\s+([-+0-9.eE]+)\s*;", b)
    if mu:
        return None                                              # uniforme: se completa con el número de caras
    mn = re.search(r"value\s+nonuniform\s+List<scalar>\s*(\d+)\s*\((.*?)\)\s*;", b, re.S)
    if mn:
        return [float(v) for v in mn.group(2).split()]
    mz = re.search(r"value\s+nonuniform\s+List<scalar>\s*0\s*\(\s*\)\s*;", b)
    return [] if mz else None


def balance(caso_a, parches=("inlet", "farfield", "outlet")):
    ruta = ultimo(os.path.join(caso_a, "[0-9]*", "phi"))
    if not ruta:
        return None
    with open(ruta, encoding="utf-8", errors="replace") as f:
        txt = f.read()
    i = txt.find("boundaryField")
    txt = txt[i:] if i >= 0 else txt
    todos, por_parche = [], {}
    for p in parches:
        v = _valores_parche(txt, p)
        if v is None:
            return {"error": f"no se pudieron leer los valores de phi en {p} ({ruta})"}
        por_parche[p] = sum(v)
        todos += v
    entrante = -sum(v for v in todos if v < 0)
    neto = sum(todos)
    return {"neto": neto, "entrante": entrante, "eps": (abs(neto) / entrante * 100) if entrante > 0 else float("nan"),
            "parches": por_parche}


# ----------------------------------------------------------------------------- y+
def yplus(caso_a, umbral):
    ruta = ultimo(os.path.join(caso_a, "postProcessing", "pared", "*", "*.xy"))
    if not ruta:
        return None
    pts = []
    with open(ruta, encoding="utf-8", errors="replace") as f:
        for linea in f:
            s = linea.strip()
            if not s or s.startswith("#"):
                continue
            try:
                v = [float(c) for c in s.split()]
            except ValueError:
                continue
            pts.append(v)
    if not pts or len(pts[0]) < 8:
        return {"error": f"{ruta}: se esperaban 8 columnas (x y z p tau_x tau_y tau_z y+), hay {len(pts[0]) if pts else 0}"}
    # peso de cada cara: la mitad de la distancia a sus vecinas siguiendo el contorno (la extrusión tiene espesor
    # constante, así que el área es proporcional a la longitud). Se ordena por ángulo alrededor del centro del perfil.
    xc = sum(p[0] for p in pts) / len(pts)
    yc = sum(p[1] for p in pts) / len(pts)
    orden = sorted(pts, key=lambda p: math.atan2(p[1] - yc, p[0] - xc))
    n = len(orden)
    w = []
    for i in range(n):
        a, b, c = orden[i - 1], orden[i], orden[(i + 1) % n]
        w.append(0.5 * (math.hypot(b[0] - a[0], b[1] - a[1]) + math.hypot(c[0] - b[0], c[1] - b[1])))
    yp = [p[7] for p in orden]
    W = sum(w)
    return {"min": min(yp), "max": max(yp), "media": sum(yp) / n,
            "media_area": sum(a * b for a, b in zip(yp, w)) / W,
            "pct": 100 * sum(a for a, b in zip(w, yp) if b <= umbral) / W, "umbral": umbral, "n": n}


# ----------------------------------------------------------------------------- principal
def angulo_de(nombre):
    return float(nombre[1:])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("caso")
    ap.add_argument("angulos", nargs="*")
    ap.add_argument("--ventana", type=int, default=200)
    ap.add_argument("--pared", type=float, default=2.0)
    a = ap.parse_args()

    if a.angulos:
        carpetas = [("a" + x) for x in a.angulos]
    else:
        carpetas = sorted((d for d in os.listdir(a.caso) if re.fullmatch(r"a-?\d+(\.\d+)?", d)), key=angulo_de)
    if not carpetas:
        sys.exit(f"No hay carpetas a<ángulo> en {a.caso}")
    carpetas.sort(key=angulo_de)

    cabecera = ["alfa", "CL", "CD", "Cm", "iteraciones", "estado"]
    filas_polar, filas_csv = [], []
    for c in carpetas:
        ruta = os.path.join(a.caso, c)
        al = angulo_de(c)
        print(f"\n=== alfa = {al:g}° ({ruta})")
        fz = fuerzas(ruta, a.ventana)
        if not fz:
            print("  Sin forceCoeffs.dat: revise log.foamRun")
            continue
        rs = residuales(ruta)
        bl = balance(ruta)
        yp = yplus(ruta, a.pared)
        fallas = []

        print(f"  CL = {fz['CL']:.5f}  CD = {fz['CD']:.6f}  Cm(c/4, nariz arriba) = {fz['Cm']:.5f}  (iteración {fz['iter']})")
        print(f"  Ventana de {fz['ventana']} iteraciones: pico a pico  CL {fz['ptp_CL']:.2e} (tol {fz['tol_CL']:.2e}),  "
              f"CD {fz['ptp_CD']:.2e} (tol {fz['tol_CD']:.2e}),  Cm {fz['ptp_Cm']:.2e} (tol {fz['tol_Cm']:.2e})")
        for k in ("CL", "CD", "Cm"):
            if not fz[f"ok_{k}"]:
                fallas.append(f"ventana_{k}")
        if fz["ventana"] < a.ventana:
            fallas.append("ventana_corta")
            print(f"  Aviso: sólo hay {fz['n']} iteraciones, menos que la ventana pedida")

        orden_min = None
        if rs:
            orden_min = min(rs.values())
            print("  Reducción de residuales (órdenes): " + ", ".join(f"{k} {v:.1f}" for k, v in rs.items()))
            if orden_min < 3:
                fallas.append("residuales<3")
        else:
            print("  Sin residuals.dat: no se puede comprobar la reducción de residuales")
            fallas.append("sin_residuales")

        eps = float("nan")
        if bl and "error" not in bl:
            eps = bl["eps"]
            print(f"  Balance de flujo: neto {bl['neto']:+.3e} m3/s, entrante {bl['entrante']:.3e} m3/s, "
                  f"εm = {eps:.4f} %")
            if not eps < 0.5:
                fallas.append("balance>0.5%")
        else:
            print("  Balance de flujo: " + (bl["error"] if bl else "no hay phi escrito"))
            fallas.append("sin_balance")

        ypd = {"min": "", "max": "", "media_area": "", "pct": ""}
        if yp and "error" not in yp:
            ypd = yp
            print(f"  y+: mín {yp['min']:.3f}, máx {yp['max']:.3f}, promedio ponderado por área {yp['media_area']:.3f}, "
                  f"{yp['pct']:.1f} % de la superficie con y+ ≤ {yp['umbral']:g}")
        else:
            print("  y+: " + (yp["error"] if yp else "no hay postProcessing/pared"))

        estado = "ok" if not fallas else "~"
        if fallas:
            print("  NO CUMPLE: " + ", ".join(fallas))
        else:
            print("  Cumple todos los criterios")
        filas_polar.append((al, fz["CL"], fz["CD"], fz["Cm"], fz["iter"], estado))
        filas_csv.append([al, fz["CL"], fz["CD"], fz["Cm"], fz["iter"], estado, ";".join(fallas),
                          fz["ptp_CL"], fz["ptp_CD"], fz["ptp_Cm"], orden_min if orden_min is not None else "", eps,
                          ypd["min"], ypd["max"], ypd["media_area"], ypd["pct"]])

    if not filas_polar:
        sys.exit("Ninguna corrida tiene resultados")
    with open(os.path.join(a.caso, "polar.dat"), "w", encoding="utf-8") as f:
        f.write("# alfa       CL        CD    Cm(c/4)  iteraciones  estado\n")
        for al, cl, cd, cm, it, est in filas_polar:
            f.write(f"{al:6g} {cl:9.5f} {cd:9.6f} {cm:10.5f} {it:12d}  {est}\n")
    enc = ["alfa", "CL", "CD", "Cm", "iteraciones", "estado", "fallas", "ptp_CL", "ptp_CD", "ptp_Cm",
           "orden_residual_min", "eps_masa_pct", "yplus_min", "yplus_max", "yplus_media_area", f"pct_yplus<={a.pared:g}"]
    with open(os.path.join(a.caso, "verificacion.csv"), "w", encoding="utf-8") as f:
        f.write(",".join(enc) + "\n")
        for fila in filas_csv:
            f.write(",".join(f"{x:.6g}" if isinstance(x, float) else str(x) for x in fila) + "\n")
    print("\n" + open(os.path.join(a.caso, "polar.dat"), encoding="utf-8").read())
    print(f"Escribí {a.caso}/polar.dat y {a.caso}/verificacion.csv")


if __name__ == "__main__":
    main()
