// Perfil NACA en dominio en C · paso 4: los diez bloques
// Los seis del Tutorial 2.2.1, con dos estaciones más por cara. Cada lazo
// empieza en el perfil o en el corte de estela y da la vuelta al bloque.
Include "perfil2_3_dominio.geo";

Curve Loop(1) = {1, 23, -11, -22};   Plane Surface(1) = {1};
Curve Loop(2) = {2, 24, -13, -23};   Plane Surface(2) = {2};
Curve Loop(3) = {3, 25, -14, -24};   Plane Surface(3) = {3};
Curve Loop(4) = {4, 26, -15, -25};   Plane Surface(4) = {4};

Curve Loop(5) = {5, 27, -12, -22};   Plane Surface(5) = {5};
Curve Loop(6) = {6, 28, -17, -27};   Plane Surface(6) = {6};
Curve Loop(7) = {7, 29, -18, -28};   Plane Surface(7) = {7};
Curve Loop(8) = {8, 30, -19, -29};   Plane Surface(8) = {8};

Curve Loop(9)  = {21, 31, -16, -26};  Plane Surface(9)  = {9};
Curve Loop(10) = {21, 32, -20, -30};  Plane Surface(10) = {10};
