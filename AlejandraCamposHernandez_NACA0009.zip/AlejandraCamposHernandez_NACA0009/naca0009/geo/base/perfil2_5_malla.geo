// Perfil NACA en dominio en C · paso 5: los nodos y la malla
// Ningún número se escribe a mano: todos salen de los pasos 1 y 2.
Include "perfil2_4_bloques.geo";

// ---- a lo largo del perfil, y la frontera que tiene enfrente -----------
// Cada tramo y su línea exterior llevan el mismo número de nodos y la misma
// progresión, de modo que los tamaños casan a lo largo de toda la frontera.
// La elipse es la excepción: mide mucho más que el tramo que tiene enfrente.
Transfinite Curve {1, 5}        = nT1 Using Progression rT1;
Transfinite Curve {11, 12}      = nT1 Using Progression rEntrada;
Transfinite Curve {2, 6, 13, 17} = nT2;
Transfinite Curve {3, 7, 14, 18} = nT3;
Transfinite Curve {4, 8, 15, 19} = nT4 Using Progression rT4;

// ---- hacia afuera: una sola progresión, de la pared al campo lejano ----
Transfinite Curve {22, 23, 24, 25, 26, 27, 28, 29, 30} = nRadial Using Progression rRadial;

// ---- a lo largo de la estela ------------------------------------------
Transfinite Curve {21, 16, 20} = nEstela Using Progression rEstela;

// ---- verticales de la salida ------------------------------------------
// No heredan la progresión de la pared: veinte cuerdas atrás, una celda de
// 2e-5 c de alto por 1.5 c de largo no tiene sentido.
Transfinite Curve {31, 32} = nRadial Using Progression rSalida;

Transfinite Surface {1:10};
Recombine Surface {1:10};

// La malla estructurada no se suaviza: el suavizado mueve los nodos que
// Transfinite acaba de colocar y rompe la simetría.
Mesh.Smoothing = 0;
