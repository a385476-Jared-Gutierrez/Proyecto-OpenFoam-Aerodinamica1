// Perfil NACA en dominio en C · paso 3: el dominio
// La C exterior es media elipse con centro en la estación de espesor máximo;
// con entrada = R es el arco de circunferencia del Tutorial 2.2.1.
Include "perfil2_2_perfil.geo";

xc = xs * c;            // centro de la C, sobre la cuerda
xf = xc - entrada;      // frente de la entrada
xo = c + L;             // salida

Point(1) = {xf, 0, 0};                  // frente
Point(2) = {xc, 0, 0};                  // centro de la elipse (queda dentro del perfil)
Point(3) = {xc, R, 0};        Point(4)  = {xc, -R, 0};
Point(5) = {xr1 * c, R, 0};   Point(6)  = {xr1 * c, -R, 0};
Point(7) = {xr2 * c, R, 0};   Point(8)  = {xr2 * c, -R, 0};
Point(9) = {c, R, 0};         Point(10) = {c, -R, 0};
Point(11) = {xo, R, 0};       Point(12) = {xo, -R, 0};
Point(13) = {xo, 0, 0};                 // fin del corte de estela

// Entrada en C: dos medias elipses de semiejes entrada (horizontal) y R (vertical).
// El tercer punto sólo fija la dirección del primer semieje; no tiene que ser el mayor.
Ellipse(11) = {1, 2, 1, 3};
Ellipse(12) = {1, 2, 1, 4};

Line(13) = {3, 5};  Line(14) = {5, 7};  Line(15) = {7, 9};  Line(16) = {9, 11};
Line(17) = {4, 6};  Line(18) = {6, 8};  Line(19) = {8, 10}; Line(20) = {10, 12};

Line(21) = {1000 + n, 13};              // corte de estela, del borde de salida a la salida

// Radiales: del perfil a la frontera, en el borde de ataque, en las tres
// estaciones de cada cara y en el borde de salida.
Line(22) = {1000, 1};
Line(23) = {1000 + ks,  3};  Line(24) = {1000 + kr1, 5};
Line(25) = {1000 + kr2, 7};  Line(26) = {1000 + n,   9};
Line(27) = {2000 + ks,  4};  Line(28) = {2000 + kr1, 6};
Line(29) = {2000 + kr2, 8};  Line(30) = {1000 + n,  10};

Line(31) = {13, 11};  Line(32) = {13, 12};      // la salida, arriba y abajo
