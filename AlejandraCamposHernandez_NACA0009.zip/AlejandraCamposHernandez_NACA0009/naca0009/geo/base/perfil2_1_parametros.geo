// Perfil NACA en dominio en C · paso 1: los parámetros
// Todo lo que se puede cambiar sin tocar el resto de los archivos.
// Cada constante se puede fijar desde la terminal:  gmsh ... -setnumber naca 2412

SetFactory("Built-in");

DefineConstant[
  // ---- perfil ----------------------------------------------------------
  naca   = {12,     Name "1Perfil/1Código NACA de 4 dígitos"},
  c      = {1.0,    Name "1Perfil/2Cuerda c (m)"},
  n      = {120,    Name "1Perfil/3Intervalos por cara"},
  xs     = {0.30,   Name "1Perfil/4Estación 1, espesor máximo (c)"},
  xr1    = {0.55,   Name "1Perfil/5Estación 2 (c)"},
  xr2    = {0.75,   Name "1Perfil/6Estación 3 (c)"},
  hBA    = {0.0005, Name "1Perfil/7Celda en el borde de ataque (c)"},
  hMed   = {0.015,  Name "1Perfil/8Celda a media cuerda (c)"},
  hBS    = {0.002,  Name "1Perfil/9Celda en el borde de salida (c)"},

  // ---- dominio ---------------------------------------------------------
  R       = {15.0, Name "2Dominio/1Radio y semialtura (c)"},
  entrada = {15.0, Name "2Dominio/2Entrada desde el centro (c)"},
  L       = {20.0, Name "2Dominio/3Estela hasta la salida (c)"},
  hFar    = {1.5,  Name "2Dominio/4Celda en el campo lejano (c)"},
  hSalida = {0.01, Name "2Dominio/5Celda vertical en la salida (c)"},

  // ---- la primera celda, a partir de y+ --------------------------------
  rho    = {1.225,    Name "3y+/1Densidad ρ (kg m⁻³)"},
  mu     = {1.789e-5, Name "3y+/2Viscosidad μ (Pa s)"},
  Uinf   = {30.0,     Name "3y+/3Velocidad U∞ (m s⁻¹)"},
  yplus  = {1.0,      Name "3y+/4y+ buscado"},

  // ---- extrusión para OpenFOAM ----------------------------------------
  e      = {0.01, Name "4OpenFOAM/1Espesor de la extrusión (m)"}
];

// ---------------------------------------------------------------- perfil
// Los dígitos del código: curvatura máxima m, su posición p y el espesor t.
Md = Floor(naca / 1000);
Pd = Floor((naca - 1000 * Md) / 100);
Td = naca - 1000 * Md - 100 * Pd;
m = Md / 100.0;     // curvatura máxima, en cuerdas
p = Pd / 10.0;      // posición de la curvatura máxima
t = Td / 100.0;     // espesor máximo, en cuerdas

// Índices de las tres estaciones de control: se invierte el espaciado coseno,
// x = [1 − cos(π i/n)]/2, y se redondea al punto más cercano del contorno.
ks  = Floor(n / Pi * Acos(1.0 - 2.0 * xs)  + 0.5);
kr1 = Floor(n / Pi * Acos(1.0 - 2.0 * xr1) + 0.5);
kr2 = Floor(n / Pi * Acos(1.0 - 2.0 * xr2) + 0.5);

// ------------------------------------------------- primera celda desde y+
// Placa plana turbulenta: Cf = 0.074 Re^(-1/5), válido para 5e5 < Re < 1e7.
nu   = mu / rho;
Rec  = Uinf * c / nu;
Cf   = 0.074 / Rec^0.2;
utau = Uinf * Sqrt(Cf / 2.0);

// y+ mide la distancia del CENTRO de la primera celda a la pared:
// la altura de la celda es el doble.
y1 = yplus * nu / utau;
hw = 2.0 * y1;

// ------------------------------------------- la progresión que empalma dos tamaños
// Reparte una longitud eL en celdas que van de eh1 a ehN sin salto en los extremos:
//   suma de la progresión:  eL = (eR·ehN − eh1)/(eR − 1)   →   eR = (eL − eh1)/(eL − ehN)
//   última celda:           ehN = eh1·eR^(eN−2)            →   eN = 2 + ln(ehN/eh1)/ln(eR)
// Devuelve eR (razón) y eN (nodos, ya redondeado).
Macro Empalme
  eR = (eL - eh1) / (eL - ehN);
  eN = 2 + Floor(Log(ehN / eh1) / Log(eR) + 0.5);
Return

// Cuando la topología fija el número de nodos, la razón ya no se despeja: se
// busca por bisección la eR que reparte eL en eN nodos empezando por eh1.
// La suma crece con la razón, así que basta partir el intervalo a la mitad.
Macro Razon
  rA = 1.0 + 1.e-9;  rB = 3.0;
  For iter In {1:80}
    rM = 0.5 * (rA + rB);
    sM = eh1 * (rM^(eN - 1) - 1.0) / (rM - 1.0);
    If (sM < eL)
      rA = rM;
    Else
      rB = rM;
    EndIf
  EndFor
  eR = 0.5 * (rA + rB);
Return

// Radial: de la pared al campo lejano, con una sola progresión que arranca en hw.
eL = R;  eh1 = hw;  ehN = hFar;  Call Empalme;
nRadial = eN;  rRadial = eR;

// Cuántas de esas celdas caen dentro de la capa límite turbulenta de una placa
// plana a esta cuerda (Schlichting): sirve para saber si la malla la resuelve.
dBL = 0.37 * c / Rec^0.2;
nBL = Log(1.0 + dBL * (rRadial - 1.0) / hw) / Log(rRadial);

// Axial en la estela: arranca con la celda del borde de salida del perfil.
eL = L;  eh1 = hBS;  ehN = hFar;  Call Empalme;
nEstela = eN;  rEstela = eR;

// Vertical en la salida: el número de nodos lo impone la radial del borde de
// salida, así que sólo queda buscar la razón que empieza en hSalida. Sin esto,
// las celdas del corte de estela seguirían midiendo hw veinte cuerdas atrás.
eL = R;  eh1 = hSalida;  eN = nRadial;  Call Razon;
rSalida = eR;
hSalidaN = hSalida * rSalida^(nRadial - 2);

Printf("Re_c = %g   Cf = %g   u_tau = %g", Rec, Cf, utau);
Printf("y+ = %g  ->  centro de la primera celda y1 = %g c, altura hw = %g c", yplus, y1, hw);
Printf("radial: %g nodos con progresión %g (de %g c a %g c)", nRadial, rRadial, hw, hFar);
Printf("capa límite estimada %g c: %g celdas dentro", dBL, nBL);
Printf("estela: %g nodos con progresión %g (de %g c a %g c)", nEstela, rEstela, hBS, hFar);
Printf("salida: %g nodos con progresión %g (de %g c a %g c)", nRadial, rSalida, hSalida, hSalidaN);
Printf("estaciones de control: i = %g, %g, %g", ks, kr1, kr2);
