// Perfil NACA en dominio en C · paso 2: el contorno del perfil
// Un NACA de cuatro dígitos, con curvatura, partido en cuatro tramos por las
// estaciones de control. De aquí salen también los nodos de cada tramo.
Include "perfil2_1_parametros.geo";

// Numeración: 1000 + i el extradós, 2000 + i el intradós. El borde de ataque
// (1000) y el de salida (1000 + n) son de las dos caras.
sTramo[] = {0, 0, 0, 0};       // longitud de arco de los cuatro tramos del extradós
xAnt = 0;  yAnt = 0;

For i In {0:n}
  x = 0.5 * (1.0 - Cos(Pi * i / n));                  // espaciado coseno
  yt = 5.0 * t * (0.2969 * Sqrt(x) - 0.1260 * x - 0.3516 * x^2
                  + 0.2843 * x^3 - 0.1036 * x^4);      // borde de salida cerrado

  yc = 0.0;  dyc = 0.0;                                // línea de curvatura
  If (m > 0)
    If (x < p)
      yc = m / p^2 * (2.0 * p * x - x^2);
      dyc = 2.0 * m / p^2 * (p - x);
    Else
      yc = m / (1.0 - p)^2 * ((1.0 - 2.0 * p) + 2.0 * p * x - x^2);
      dyc = 2.0 * m / (1.0 - p)^2 * (p - x);
    EndIf
  EndIf
  th = Atan(dyc);

  // El espesor se mide perpendicular a la línea de curvatura: con curvatura,
  // las dos caras no comparten la abscisa.
  xu = c * (x - yt * Sin(th));   yu = c * (yc + yt * Cos(th));
  xl = c * (x + yt * Sin(th));   yl = c * (yc - yt * Cos(th));

  Point(1000 + i) = {xu, yu, 0};
  If (i > 0 && i < n)
    Point(2000 + i) = {xl, yl, 0};
  EndIf

  If (i > 0)                     // arco recorrido, para repartir los nodos
    dS = Sqrt((xu - xAnt)^2 + (yu - yAnt)^2);
    If (i <= ks)        sTramo[0] += dS;
    ElseIf (i <= kr1)   sTramo[1] += dS;
    ElseIf (i <= kr2)   sTramo[2] += dS;
    Else                sTramo[3] += dS;
    EndIf
  EndIf
  xAnt = xu;  yAnt = yu;
EndFor

// Cuatro tramos por cara, del borde de ataque al de salida.
Spline(1) = {1000 : 1000 + ks};
Spline(2) = {1000 + ks : 1000 + kr1};
Spline(3) = {1000 + kr1 : 1000 + kr2};
Spline(4) = {1000 + kr2 : 1000 + n};

Spline(5) = {1000, 2001 : 2000 + ks};
Spline(6) = {2000 + ks : 2000 + kr1};
Spline(7) = {2000 + kr1 : 2000 + kr2};
Spline(8) = {2000 + kr2 : 2000 + n - 1, 1000 + n};

// Sólo quedan visibles los puntos que hacen falta para construir el dominio.
Hide { Point{1001 : 1000 + n - 1, 2001 : 2000 + n - 1}; }
Show { Point{1000 + ks, 1000 + kr1, 1000 + kr2, 2000 + ks, 2000 + kr1, 2000 + kr2}; }

// ---------------------------------------------- nodos a lo largo del perfil
// Mandan los tamaños: la celda del borde de ataque, la de media cuerda y la del
// borde de salida. Cada tramo reparte su arco entre dos de esos tamaños. Los
// puntos del contorno sólo dan la forma: Transfinite reparte por longitud de
// arco, no por puntos de control.
eL = sTramo[0];  eh1 = hBA;   ehN = hMed;  Call Empalme;
nT1 = eN;  rT1 = eR;
nT2 = 1 + Floor(sTramo[1] / hMed + 0.5);   rT2 = 1.0;
nT3 = 1 + Floor(sTramo[2] / hMed + 0.5);   rT3 = 1.0;
eL = sTramo[3];  eh1 = hMed;  ehN = hBS;   Call Empalme;
nT4 = eN;  rT4 = eR;

// La media elipse de la entrada lleva los mismos nodos que el primer tramo del
// perfil, pero mide veinte veces más: sin progresión, sus celdas serían cien
// veces las de la línea de arriba. Se recorre del frente hacia arriba, así que
// la razón se calcula al revés.
hArriba = sTramo[1] / (nT2 - 1);
sElipse = Pi * (3.0 * (entrada + R)
                - Sqrt((3.0 * entrada + R) * (entrada + 3.0 * R))) / 4.0;   // Ramanujan
eL = sElipse;  eh1 = hArriba;  eN = nT1;
Call Razon;
rEntrada = 1.0 / eR;
hEntrada1 = hArriba * eR^(nT1 - 2);

Printf("arcos del extradós: %g, %g, %g, %g", sTramo[0], sTramo[1], sTramo[2], sTramo[3]);
Printf("tramo 1: %g nodos con progresión %g (de %g c a %g c)", nT1, rT1, hBA, hMed);
Printf("tramos 2 y 3: %g y %g nodos, celdas de %g c", nT2, nT3, hMed);
Printf("tramo 4: %g nodos con progresión %g (de %g c a %g c)", nT4, rT4, hMed, hBS);
Printf("celdas alrededor del perfil: %g", 2 * (nT1 + nT2 + nT3 + nT4 - 4));
Printf("entrada: %g nodos, celdas de %g c (frente) a %g c (arriba)", nT1, hEntrada1, hArriba);
