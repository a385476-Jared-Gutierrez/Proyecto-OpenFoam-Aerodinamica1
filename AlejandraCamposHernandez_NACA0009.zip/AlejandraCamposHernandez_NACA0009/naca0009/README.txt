PASOS PARA CORRER SIMULACIONES DEL PERFIL NACA 0009
Responsable: ALejandra Campos Hernandez

1. Preparacion preliminar y aclaraciones

Todo lo que empieza con # es un comentario: no se escribe.
Cada línea sin # se escribe en la terminal y se presiona Enter.
"python" y "python3" son equivalentes, usar el contrario en caso de que uno no responda.
Estos pasos son correspondientes a la carpeta naca0009, la otra carpeta en este ZIP incluye
unicamente archivos de datos csv, graficas svg y logs ligeros resultantes de la simulacion
previamente hecha.
La se recomienda que la carpeta naca0009 sea copiada a la carpeta "RUN" en OpenFoam, de otra
manera se tendran que modificar los comandos de rutas de archivos en este README


#PARTE A. SIMULACIONES (OpenFOAM)                                   

1. PREPARAR (una sola vez)

# Con la carpeta naca0009 ya en "RUN" indicar la ruta en la terminal de OpenFOAM mediante:

cd $FOAM_RUN/naca0009

# Exportar la localizacion de Gmsh (cambiar la ruta por la localizacion de Gmsh en su dispositivo):
export PATH="$PATH:/c/Users/NomUsuario/Desktop/gmsh-4.15.2-Windows64"
gmsh --version                        # debe responder la version del Gmsh del usuario

chmod +x Allmalla Allpolar


3. LA MALLA MEDIA

./Allmalla base media

# Al final imprime dos revisiones de checkMesh:
#   checkMesh sencillo:      debe decir "Mesh OK"
#   checkMesh -allGeometry:  muy probablemente arroje "Failed 1 mesh checks" por la prueba de determinante de celda
#                            (~1500 celdas de capa límite muy alargadas, y+ ~ 1). Es un aviso a declarar en el reporte.
# El detalle está en casos/base_media/log.checkMesh y log.checkMesh_basico.



4. PRIMERA PRUEBA: UN SOLO ÁNGULO

./Allpolar casos/base_media 0

# Correr la simulacion con un solo angulo para confirmar el correcto funcionamiento

5. ESTUDIO DE MALLA (nivel 1)

./Allmalla base gruesa
./Allmalla base fina
./Allpolar casos/base_gruesa 0 8
./Allpolar casos/base_media  0 8
./Allpolar casos/base_fina   0 8
python scripts/estudio_malla.py casos/base_gruesa casos/base_media casos/base_fina

# Proceso de simulacion para nivel 1

6. BARRIDO DE ÁNGULOS (nivel 2) en la malla elegida

# Se realizo la simulacion con 3 nucleos, cambiar el numero de PARALELO segun sea conveniente. No poner
# este comando hara que se use un nucleo para cada angulo hasta que no haya mas angulos o nucleos

PARALELO=3 ./Allpolar casos/base_media 18 17 16 15 14 12 10 8 4 0 -4

# Si se interrumpe: vuelva a correr ESE mismo comando (ver sección 2).
# Si un ángulo sale con "~" porque le faltaron iteraciones, repítalo con más (REHACER=1 porque ya existe):
REHACER=1 ITER=6000 ./Allpolar casos/base_media 18

   PARTE B. POSTPROCESO, GRÁFICAS Y TABLAS (scripts)                     

# Estos comandos NO corren simulaciones: leen los resultados que ya están en casos/. Se pueden repetir cuantas veces
# se quiera y se corren después de cada tanda de la Parte A. Todos desde la carpeta naca2415.



10. GRÁFICA DE CONVERGENCIA DE CADA SIMULACIÓN 

# Un comando por caso hace las de todos sus ángulos:
python scripts/graficar_corrida.py casos/base_gruesa
python scripts/graficar_corrida.py casos/base_media
python scripts/graficar_corrida.py casos/base_fina

# Cada una deja convergencia_a<ángulo>.svg dentro de la carpeta del ángulo: ábralo con doble clic (navegador).


11. PRESIÓN Y FRICCIÓN (cp y cf por superficie)

# cp(x/c) de extradós e intradós en TRES ángulos del barrido (uno bajo, uno moderado y uno alto = 18):
python scripts/cp_cf.py casos/base_media/a0 casos/base_media/a8 casos/base_media/a18
# escribe cp_cf_a<ángulo>.csv  y la gráfica .svg dentro de cada carpeta de ángulo.

# El cp también hay que sacarlo en las TRES mallas, en 0 y 8 :
python scripts/cp_cf.py casos/base_gruesa/a0 casos/base_gruesa/a8
python scripts/cp_cf.py casos/base_fina/a0 casos/base_fina/a8
python scripts/cp_cf.py casos/base_media/a0 casos/base_media/a8
# y en el control de dominio (UN perfil), para comparar con base_media a 8:
python scripts/cp_cf.py casos/lejano_U30/a8
# (los scripts no superponen estas curvas: de momento se juntan a mano con los CSV.)



12. POLAR, TABLA DE CARGAS Y y+ (graficar_polar.py)

# --- 1. Barrido de la malla elegida (nivel 2): tabla con cargas, curvas y métricas ---
python scripts/graficar_polar.py casos/base_media

# --- 2. y+(x/c) de la malla elegida: las dos incidencias de verificación y la MAYOR del barrido (obligatorio) ---
python scripts/graficar_polar.py --yplus casos/base_media/a0 casos/base_media/a8 casos/base_media/a18
#   Deja yplus_a0.svg, yplus_a8.svg y yplus_a18.svg dentro de cada carpeta de ángulo

# --- 3. Validación (nivel 3): la polar del caso a Re = 6e6 ---
python scripts/graficar_polar.py casos/val_Re6e6