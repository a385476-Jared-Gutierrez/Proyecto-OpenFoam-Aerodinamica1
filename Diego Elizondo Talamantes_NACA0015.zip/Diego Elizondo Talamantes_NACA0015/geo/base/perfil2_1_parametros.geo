// Perfil NACA en dominio en C · paso 1: los parámetros
// Todo lo que se puede cambiar sin tocar el resto de los archivos.
// Cada constante se puede fijar desde la terminal:  gmsh ... -setnumber naca 2412

SetFactory("Built-in");

DefineConstant[
  // ---- perfil ----------------------------------------------------------
  naca   = {15,     Name "1Perfil/1Código NACA de 4 dígitos"},
  c      = {1.0,    Name "1Perfil/2Cuerda c (m)"},
  n      = {120,    Name "1Perfil/3Intervalos por cara"},
  xs     = {0.30,   Name "1Perfil/4Estación 1, espesor máximo (c)"},
  xr1    = {0.55,   Name "1Perfil/5Estación 2 (c)"},
  xr2    = {0.75,   Name "1Perfil/6Estación 3 (c)"},
  hBA    = {0.0005, Name "1Perfil/7Celda en el borde de ataque (c)"},
  hMed   = {0.015,  Name "1Perfil/8Celda a media cuerda (c)"},
  hBS    = {0.002,  Name "1Perfil/9Celda en el borde de salida (c)"},
  alpha  = {0.0,    Name "1Perfil/10Ángulo de ataque α (°)"},

  // ---- dominio ---------------------------------------------------------
  R       = {15.0, Name "2Dominio/1Radio y semialtura (c)"},
  entrada = {15.0, Name "2Dominio/2Entrada desde el centro (c)"},
  L       = {20.0, Name "2Dominio/3Estela hasta la salida (c)"},
  hFar    = {1.5,  Name "2Dominio/4Celda en el campo lejano (c)"},
  hSalida = {0.01, Name "2Dominio/5Celda vertical en la salida (c)"},

  // ---- la primera celda, a partir de y+ --------------------------------
  rho    = {1.225,    Name "3y+/1Densidad ρ (kg m⁻³)"},
  mu     = {1.789e-5, Name "3y+/2Viscosidad μ (Pa s)"},
  Uinf   = {30.0,     Name "3y+/3Velocidad U∞ (m s⁻¹)"},
  yplus  = {1.0,      Name "3y+/4y+ buscado"},

  // ---- extrusión para OpenFOAM ----------------------------------------
  e      = {0.01, Name "4OpenFOAM/1Espesor de la extrusión (m)"}
];

// ---------------------------------------------------------------- perfil
Md = Floor(naca / 1000);
Pd = Floor((naca - 1000 * Md) / 100);
Td = naca - 1000 * Md - 100 * Pd;
m = Md / 100.0;     // curvatura máxima, en cuerdas
p = Pd / 10.0;      // posición de la curvatura máxima
t = Td / 100.0;     // espesor máximo, en cuerdas

// Orientación de la estela según el ángulo de ataque (Opción A: salida vertical fija)
alphaRad = alpha * Pi / 180.0;
yOut     = L * Tan(alphaRad);

// Índices de las tres estaciones de control
ks  = Floor(n / Pi * Acos(1.0 - 2.0 * xs)  + 0.5);
kr1 = Floor(n / Pi * Acos(1.0 - 2.0 * xr1) + 0.5);
kr2 = Floor(n / Pi * Acos(1.0 - 2.0 * xr2) + 0.5);

// ------------------------------------------------- primera celda desde y+
nu   = mu / rho;
Rec  = Uinf * c / nu;
Cf   = 0.074 / Rec^0.2;
utau = Uinf * Sqrt(Cf / 2.0);

y1 = yplus * nu / utau;
hw = 2.0 * y1;

// ------------------------------------------- progresiones
Macro Empalme
  eR = (eL - eh1) / (eL - ehN);
  eN = 2 + Floor(Log(ehN / eh1) / Log(eR) + 0.5);
Return

Macro Razon
  If (eh1 * (eN - 1) >= eL)
    eR = 1.0;
  Else
    rA = 1.0 + 1.e-9;  rB = 3.0;
    For iter In {1:80}
      rM = 0.5 * (rA + rB);
      sM = eh1 * (rM^(eN - 1) - 1.0) / (rM - 1.0);
      If (sM < eL)
        rA = rM;
      Else
        rB = rM;
      EndIf
    EndFor
    eR = 0.5 * (rA + rB);
  EndIf
Return

// Radial: de la pared al campo lejano
eL = R;  eh1 = hw;  ehN = hFar;  Call Empalme;
nRadial = eN;  rRadial = eR;

dBL = 0.37 * c / Rec^0.2;
nBL = Log(1.0 + dBL * (rRadial - 1.0) / hw) / Log(rRadial);

// Axial en la estela
eL = L;  eh1 = hBS;  ehN = hFar;  Call Empalme;
nEstela = eN;  rEstela = eR;

// Vertical en la salida: tramo superior (R - yOut) y tramo inferior (R + yOut)
eL = R - yOut;  eh1 = hSalida;  eN = nRadial;  Call Razon;
rSalidaSup = eR;
hSalidaNSup = hSalida * rSalidaSup^(nRadial - 2);

eL = R + yOut;  eh1 = hSalida;  eN = nRadial;  Call Razon;
rSalidaInf = eR;
hSalidaNInf = hSalida * rSalidaInf^(nRadial - 2);

Printf("Re_c = %g   Cf = %g   u_tau = %g   alpha = %g deg (yOut = %g c)", Rec, Cf, utau, alpha, yOut);
Printf("y+ = %g  ->  centro de la primera celda y1 = %g c, altura hw = %g c", yplus, y1, hw);
Printf("radial: %g nodos con progresión %g (de %g c a %g c)", nRadial, rRadial, hw, hFar);
Printf("capa límite estimada %g c: %g celdas dentro", dBL, nBL);
Printf("estela: %g nodos con progresión %g (de %g c a %g c)", nEstela, rEstela, hBS, hFar);
Printf("salida sup/inf: %g nodos con progresión %g / %g", nRadial, rSalidaSup, rSalidaInf);
Printf("estaciones de control: i = %g, %g, %g", ks, kr1, kr2);
