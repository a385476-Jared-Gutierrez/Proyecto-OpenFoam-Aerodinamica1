// Perfil NACA en dominio en C · paso 5: los nodos y la malla
// Ningún número se escribe a mano: todos salen de los pasos 1 y 2.
Include "perfil2_4_bloques.geo";

// ---- a lo largo del perfil, y la frontera que tiene enfrente -----------
Transfinite Curve {1, 5}        = nT1 Using Progression rT1;
Transfinite Curve {11, 12}      = nT1 Using Progression rEntrada;
Transfinite Curve {2, 6, 13, 17} = nT2;
Transfinite Curve {3, 7, 14, 18} = nT3;
Transfinite Curve {4, 8, 15, 19} = nT4 Using Progression rT4;

// ---- hacia afuera: una sola progresión, de la pared al campo lejano ----
Transfinite Curve {22, 23, 24, 25, 26, 27, 28, 29, 30} = nRadial Using Progression rRadial;

// ---- a lo largo de la estela ------------------------------------------
Transfinite Curve {21, 16, 20} = nEstela Using Progression rEstela;

// ---- verticales de la salida (ajustadas a R - yOut y R + yOut) ---------
Transfinite Curve {31} = nRadial Using Progression rSalidaSup;
Transfinite Curve {32} = nRadial Using Progression rSalidaInf;

Transfinite Surface {1:10};
Recombine Surface {1:10};

Mesh.Smoothing = 0;