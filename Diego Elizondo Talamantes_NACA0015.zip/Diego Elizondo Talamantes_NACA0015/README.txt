PROYECTO NACA 0015 (NIVEL 1, NIVEL 2 Y EXTRA)
Entorno: Terminal MINGW64 OpenFOAM-12 + Gmsh + Python 3 + rsvg-convert







FASE 0. PREPARACIÓN DEL ENTORNO Y MIGRACIÓN DE PLANTILLA (naca2415 -> naca0015)

cd /c/Users/deliz/Downloads/nacaXXXX/naca2415

# 0.1 Localizar gmsh.exe y registrarlo permanentemente en ~/.bashrc:
GMSH_EXE=$(find /c /c/Users/deliz/Downloads /c/Users/deliz/Desktop /c/Users/deliz/Documents "/c/Program Files" "/c/Program Files (x86)" -maxdepth 4 -iname "gmsh.exe" 2>/dev/null | head -n 1)
if [ -n "$GMSH_EXE" ]; then
    GMSH_DIR=$(dirname "$GMSH_EXE")
    echo "Encontrado en: $GMSH_DIR"
    export PATH="$PATH:$GMSH_DIR"
    grep -qxF "export PATH=\"\$PATH:$GMSH_DIR\"" ~/.bashrc || echo "export PATH=\"\$PATH:$GMSH_DIR\"" >> ~/.bashrc
fi

# 0.2 Clonar proyecto hacia naca0015 y cambiar perfil por defecto a NACA 0015:
cd /c/Users/deliz/Downloads/nacaXXXX
rm -rf naca2415/casos/prueba_a16
cp -r naca2415 naca0015
cd naca0015
sed -i 's/NACA=${NACA:-2415}/NACA=${NACA:-15}/' Allmalla



FASE 1 (NIVEL 1). MALLAS BASE, INDEPENDENCIA DE MALLA Y POLAR ESTACIONARIA RANS



1.1 Generación de las tres densidades de malla en dominio base

POR QUÉ:
Antes de calcular el barrido angular completo, es indispensable construir tres
niveles de refinamiento espacial (gruesa, media y fina) para verificar la
independencia de los resultados respecto a la discretización espacial.

COMANDOS:
./Allmalla base gruesa
./Allmalla base media
./Allmalla base fina


1.2 Estudio de independencia de malla a alpha = 0 deg y alpha = 8 deg


./Allpolar casos/base_gruesa 0 8
./Allpolar casos/base_media 0 8
./Allpolar casos/base_fina 0 8

# Si se requiere asegurar convergencia profunda en malla gruesa a alpha = 0 deg:
REHACER=1 ITER=3500 ./Allpolar casos/base_gruesa 0

# Tabla comparativa de independencia de malla:
python3 scripts/estudio_malla.py casos/base_gruesa casos/base_media casos/base_fina


1.3 Barrido angular estacionario completo en la malla elegida (base_media)



./Allpolar casos/base_media -4 0 4 8 10 12 14 15 16 17 18

# Extender convergencia estacionaria en entrada en pérdida (alpha = 18 deg, 8000 iter):
REHACER=1 ITER=8000 ./Allpolar casos/base_media 18

# Verificar resolución de capa límite (y+ < 1 en pared):
tail -n 3 casos/base_media/a18/postProcessing/yPlus/0/yPlus.dat



FASE 2 (NIVEL 2). SENSIBILIDAD AL DOMINIO LEJANO (R=100, L=100) Y VALIDACIÓN



2.1 Malla de dominio lejano estándar (lejano_media) y barrido angular

sed -i 's/naca   = {12,/naca   = {15,/' geo/lejano/perfil3_1_parametros.geo
./Allmalla lejano media

# Comparación directa a alpha = 0 y 8 deg:
./Allpolar casos/lejano_media 0 8
cat casos/base_media/polar.dat
cat casos/lejano_media/polar.dat

# Barrido angular completo en dominio lejano:
./Allpolar casos/lejano_media 0 2 4 6 8 10 12 14 15 16


2.2 Prueba de frontera extendida a 100 cuerdas (R=100, L=100) con U_inf = 30 m/s
NOMBRE=lejano_U30 UINF=30 R=100 L=100 ./Allmalla lejano media
REHACER=1 ITER=3500 UINF=30 ./Allpolar casos/lejano_U30 8



FASE 3 (NIVEL EXTRA). SIMULACIÓN TRANSITORIA URANS EN STALL (alpha = 18 deg)



3.1 Estabilización inicial (PIMPLE consistente) y verificación temporal dt vs dt/2


rm -rf casos/urans_dt1 casos/urans_dt2
python3 -c '
import shutil, re
fsch = """FoamFile
{
    format      ascii;
    class       dictionary;
    location    "system";
    object      fvSchemes;
}
ddtSchemes       { default Euler; }
gradSchemes      { default cellLimited Gauss linear 1; }
divSchemes
{
    default          none;
    div(phi,U)       bounded Gauss linearUpwindV grad(U);
    div(phi,nuTilda) bounded Gauss upwind;
    div((nuEff*dev2(T(grad(U))))) Gauss linear;
}
laplacianSchemes     { default Gauss linear limited 0.5; }
interpolationSchemes { default linear; }
snGradSchemes        { default limited 0.5; }
wallDist             { method meshWave; }
"""
fsol = """FoamFile
{
    format      ascii;
    class       dictionary;
    location    "system";
    object      fvSolution;
}
solvers
{
    p       { solver PCG; preconditioner DIC; tolerance 1e-06; relTol 0.05; }
    pFinal  { solver PCG; preconditioner DIC; tolerance 1e-06; relTol 0; }
    "(U|nuTilda)"      { solver smoothSolver; smoother GaussSeidel; nSweeps 2; tolerance 1e-07; relTol 0.1; }
    "(U|nuTilda)Final" { solver smoothSolver; smoother GaussSeidel; nSweeps 2; tolerance 1e-07; relTol 0; }
}
PIMPLE
{
    consistent               yes;
    nOuterCorrectors         2;
    nCorrectors              1;
    nNonOrthogonalCorrectors 1;
}
relaxationFactors
{
    equations { "(U|nuTilda)" 0.8; "(U|nuTilda)Final" 1.0; }
}
"""
cd_base = re.sub(r"(#includeFunc\s+(?:wallShearStress|yPlus|patchSurface))", r"// \1",
          re.sub(r"writeInterval\s+[0-9.eE+-]+;", "writeInterval   0.005;",
          re.sub(r"writeControl\s+\w+;", "writeControl    runTime;",
          re.sub(r"endTime\s+[0-9.eE+-]+;", "endTime         0.20;",
          open("casos/base_media/a18/system/controlDict", encoding="utf-8").read(), count=1), count=1), count=1))

for n, dt in (("urans_dt1", "2.5e-05"), ("urans_dt2", "1.25e-05")):
    shutil.copytree("casos/base_media/a18", f"casos/{n}", ignore=shutil.ignore_patterns("8000","postProcessing","log.*","*.svg","*.csv"), dirs_exist_ok=True)
    for f in ("U", "nuTilda", "nut", "p", "phi"):
        shutil.copy2(f"casos/base_media/a18/8000/{f}", f"casos/{n}/0/{f}")
    open(f"casos/{n}/system/controlDict", "w", encoding="utf-8").write(re.sub(r"deltaT\s+[0-9.eE+-]+;", f"deltaT          {dt};", cd_base, count=1))
    open(f"casos/{n}/system/fvSchemes", "w", encoding="utf-8").write(fsch)
    open(f"casos/{n}/system/fvSolution", "w", encoding="utf-8").write(fsol)
print("CONFIG_PIMPLEC_OK")
'

(cd casos/urans_dt1 && foamRun > log.foamRun 2>&1) &
(cd casos/urans_dt2 && foamRun > log.foamRun 2>&1) &
wait

# Extraer vorticidad y y+ en urans_dt2:
(cd casos/urans_dt2 && touch urans_dt2.foam && foamPostProcess -func vorticity > log.vorticity 2>&1 && foamPostProcess -func yPlus -latestTime > log.yPlus 2>&1)


3.2 Refinamiento temporal adicional dt/2 = 6.25e-6 s (urans_dt3)

python3 -c '
import os, shutil, re, glob, math
shutil.rmtree("casos/urans_dt3", True)
os.makedirs("casos/urans_dt3", exist_ok=True)
shutil.copytree("casos/urans_dt2/constant", "casos/urans_dt3/constant")
shutil.copytree("casos/urans_dt2/system", "casos/urans_dt3/system")
shutil.copytree("casos/urans_dt2/0.15", "casos/urans_dt3/0.15")
cd = open("casos/urans_dt2/system/controlDict", encoding="utf-8").read()
cd = re.sub(r"startFrom\s+\w+;", "startFrom       startTime;", cd, count=1)
cd = re.sub(r"startTime\s+[0-9.eE+-]+;", "startTime       0.15;", cd, count=1)
cd = re.sub(r"endTime\s+[0-9.eE+-]+;", "endTime         0.20;", cd, count=1)
cd = re.sub(r"deltaT\s+[0-9.eE+-]+;", "deltaT          6.25e-06;", cd, count=1)
cd = re.sub(r"writeInterval\s+[0-9.eE+-]+;", "writeInterval   0.01;", cd, count=1)
open("casos/urans_dt3/system/controlDict", "w", encoding="utf-8").write(cd)
'
(cd casos/urans_dt3 && foamRun > log.foamRun 2>&1)

# Generar tabla de comparación dt2 vs dt3 (casos/urans_dt3/comparacion_dt.csv):
python3 -c '
import glob, math
load = lambda p: [[float(x) for x in l.split()[:4]] for l in open(p, encoding="utf-8") if l.strip() and not l.lstrip().startswith("#")]
stats = lambda rows: (sum(r[3] for r in rows)/len(rows), sum(r[2] for r in rows)/len(rows), sum(r[1] for r in rows)/len(rows))
d2 = [r for r in load("casos/urans_dt2/postProcessing/fuerzas/0/forceCoeffs.dat") if r[0] >= 0.15]
f3 = glob.glob("casos/urans_dt3/postProcessing/fuerzas/*/forceCoeffs.dat")[0]
d3 = [r for r in load(f3) if r[0] >= 0.15]
cl2, cd2, cm2 = stats(d2)
cl3, cd3, cm3 = stats(d3)
open("casos/urans_dt3/comparacion_dt.csv", "w", encoding="utf-8").write(
    f"metrica,dt2_1.25e-5,dt3_6.25e-6,dif_pct\n"
    f"CL_medio,{cl2:.6f},{cl3:.6f},{abs(cl3-cl2)/abs(cl2)*100:.4f}\n"
    f"CD_medio,{cd2:.6f},{cd3:.6f},{abs(cd3-cd2)/abs(cd2)*100:.4f}\n"
    f"Cm_medio,{cm2:.6f},{cm3:.6f},{abs(cm3-cm2)/abs(cm2)*100:.4f}\n"
)
print("OK: casos/urans_dt3/comparacion_dt.csv")
'


3.3 Simulación extendida de 2do orden en paralelo (urans_stall, t = 0.50 s, 8 cores)

cp -r casos/urans_dt1 casos/urans_stall

cat << 'EOF' > scripts/prep_urans_stall.py
import pathlib, re, shutil

c = pathlib.Path("casos/urans_stall")
for f in ["phi", "wallShearStress", "yPlus"]:
    (c/"0"/f).unlink(missing_ok=True)
shutil.rmtree(c/"0/uniform", ignore_errors=True)

hdr = lambda cls, loc, obj: f"FoamFile\n{{\n    format ascii;\n    class {cls};\n    location \"{loc}\";\n    object {obj};\n}}\n"

(c/"0/U").write_text(hdr("volVectorField","0","U") + "dimensions [0 1 -1 0 0 0 0];\ninternalField uniform (28.5317 9.27051 0);\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type noSlip; }\n  inlet { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n  farfield { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n  outlet { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n}\n", encoding="utf-8")
(c/"0/p").write_text(hdr("volScalarField","0","p") + "dimensions [0 2 -2 0 0 0 0];\ninternalField uniform 0;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type zeroGradient; }\n  inlet { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n  farfield { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n  outlet { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n}\n", encoding="utf-8")
(c/"0/nuTilda").write_text(hdr("volScalarField","0","nuTilda") + "dimensions [0 2 -1 0 0 0 0];\ninternalField uniform 4.3812e-05;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type fixedValue; value uniform 0; }\n  inlet { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n  farfield { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n  outlet { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n}\n", encoding="utf-8")
(c/"0/nut").write_text(hdr("volScalarField","0","nut") + "dimensions [0 2 -1 0 0 0 0];\ninternalField uniform 3.0733e-06;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type nutUSpaldingWallFunction; Cmu 0.09; kappa 0.41; E 9.8; value uniform 0; }\n  inlet { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n  farfield { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n  outlet { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n}\n", encoding="utf-8")
(c/"system/decomposeParDict").write_text(hdr("dictionary","system","decomposeParDict") + "numberOfSubdomains 8;\nmethod scotch;\n", encoding="utf-8")

(c/"system/fvSchemes").write_text((c/"system/fvSchemes").read_text(encoding="utf-8").replace("Euler;", "backward;"), encoding="utf-8")
cd = (c/"system/controlDict").read_text(encoding="utf-8")
cd = re.sub(r"endTime\s+0\.20;", "endTime         0.50;", cd)
cd = re.sub(r"deltaT\s+2\.5e-05;", "deltaT          1.25e-05;\nadjustTimeStep  yes;\nmaxCo           50.0;\nmaxDeltaT       2.5e-05;", cd)
cd = re.sub(r"writeControl\s+runTime;", "writeControl    adjustableRunTime;", cd)
cd = re.sub(r"writeInterval\s+0\.005;", "writeInterval   0.01;", cd)
(c/"system/controlDict").write_text(cd, encoding="utf-8")
print("OK: casos/urans_stall listo")
EOF

python3 scripts/prep_urans_stall.py
rm -rf casos/urans_stall/processor* casos/urans_stall/log.* casos/urans_stall/postProcessing
decomposePar -case casos/urans_stall > casos/urans_stall/log.decomposePar 2>&1
mpiexec -np 8 foamRun -case casos/urans_stall -parallel > casos/urans_stall/log.foamRun 2>&1






FASE 4. EJECUCIÓN ORDENADA DE TODOS LOS SCRIPTS DE TABLAS Y GRÁFICAS FINALES


# 4.1 Tabla y verificación de independencia de malla (Nivel 1):
python3 scripts/estudio_malla.py casos/base_gruesa casos/base_media casos/base_fina

# 4.2 Historias de convergencia estacionaria de cada corrida (Nivel 1 y Nivel 2):
python3 scripts/graficar_corrida.py casos/base_media
python3 scripts/graficar_corrida.py casos/base_gruesa casos/base_fina casos/lejano_media

# 4.3 Distribuciones de presión (Cp) y fricción (Cf) sobre el perfil (Nivel 1 y 2):
python3 scripts/cp_cf.py casos/base_media/a0 casos/base_media/a8 casos/base_media/a15
python3 scripts/cp_cf.py casos/base_media/a16
python3 scripts/cp_cf.py casos/base_media/a17
python3 scripts/cp_cf.py casos/lejano_U30/a8

# 4.4 Curvas polares comparativas y validación experimental (Nivel 1 y Nivel 2):
python3 scripts/comparar_cl.py

# 4.5 Estadísticas transitorias completas de urans_stall (N = 14,001 muestras):
python3 scripts/resumen_urans_stall.py

# 4.6 Generación de las figuras vectoriales PDF del Nivel Extra (figuras_p9/):
#     - fig_p9_historias_coeficientes.pdf (urans_stall t in [0, 0.50] s, sin pico inicial)
#     - fig_p9_comparacion_dt.pdf         (verificación dt2 vs dt3 en t in [0.15, 0.20] s)
cat << 'EOF' > scripts/generar_figuras_p9.py
import pathlib
import statistics
import subprocess

out = pathlib.Path("figuras_p9")
out.mkdir(exist_ok=True)


def leer_dat(caso):
    p = pathlib.Path("casos") / caso / "postProcessing"
    for f in sorted(p.rglob("*.dat")):
        cols, rows = [], []
        txt = f.read_text(encoding="utf-8", errors="ignore")
        for ln in txt.splitlines():
            s = ln.strip()
            if s.startswith("#") and ("Cl" in s or "Cd" in s):
                cols = s.lstrip("#").split()
            elif s and not s.startswith("#"):
                rows.append([float(x) for x in s.split()])
        if rows and cols:
            idx = {n: i for i, n in enumerate(cols)}
            t = [r[idx.get("Time", 0)] for r in rows]
            cl = [r[idx.get("Cl", 3)] for r in rows]
            cd = [r[idx.get("Cd", 1)] for r in rows]
            cm = [r[idx.get("CmPitch", idx.get("Cm", 2))] for r in rows]
            return t, cl, cd, cm
    return None


def hacer_svg(nombre, titulo, xlabel, panels, tmin, tmax, shade=None):
    W, H = 860, 680
    ml, mr, mt, mb = 85, 30, 55, 50
    pw = W - ml - mr
    ph = (H - mt - mb - 40) / 3.0
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">']
    svg.append('<rect width="100%" height="100%" fill="white"/>')
    svg.append(
        f'<text x="{W/2}" y="26" text-anchor="middle" '
        f'font-family="Arial" font-size="15" font-weight="bold">'
        f'{titulo}</text>'
    )
    for k, pan in enumerate(panels):
        y0 = mt + k * (ph + 15)
        all_y = [v for s in pan["series"] for v in s["y"]]
        for ref in pan.get("refs", []):
            all_y.append(ref["val"])
        ymin, ymax = min(all_y), max(all_y)
        pad = (ymax - ymin) * 0.14 or 0.01
        ymin -= pad
        ymax += pad
        sx = lambda t: ml + (t - tmin) / (tmax - tmin) * pw
        sy = lambda v: y0 + ph - (v - ymin) / (ymax - ymin) * ph
        if shade is not None:
            x_s = sx(shade)
            svg.append(
                f'<rect x="{ml:.1f}" y="{y0:.1f}" '
                f'width="{x_s-ml:.1f}" height="{ph:.1f}" '
                f'fill="#e6e6e6"/>'
            )
        for j in range(5):
            yv = ymin + j * (ymax - ymin) / 4.0
            yp = sy(yv)
            svg.append(
                f'<line x1="{ml}" y1="{yp:.1f}" x2="{ml+pw}" '
                f'y2="{yp:.1f}" stroke="#dddddd" stroke-width="1"/>'
            )
            svg.append(
                f'<text x="{ml-8}" y="{yp+4:.1f}" text-anchor="end" '
                f'font-family="Arial" font-size="11">{yv:.4f}</text>'
            )
        for j in range(6):
            tv = tmin + j * (tmax - tmin) / 5.0
            xp = sx(tv)
            svg.append(
                f'<line x1="{xp:.1f}" y1="{y0:.1f}" x2="{xp:.1f}" '
                f'y2="{y0+ph:.1f}" stroke="#dddddd" stroke-width="1"/>'
            )
            if k == 2:
                svg.append(
                    f'<text x="{xp:.1f}" y="{y0+ph+18:.1f}" '
                    f'text-anchor="middle" font-family="Arial" '
                    f'font-size="11">{tv:.3f}</text>'
                )
        for ref in pan.get("refs", []):
            yr = sy(ref["val"])
            svg.append(
                f'<line x1="{ml}" y1="{yr:.1f}" x2="{ml+pw}" '
                f'y2="{yr:.1f}" stroke="{ref["c"]}" '
                f'stroke-dasharray="{ref["dash"]}" stroke-width="1.5"/>'
            )
        for s in pan["series"]:
            step = max(1, len(s["t"]) // 2500)
            pts = " ".join(
                f"{sx(s['t'][i]):.1f},{sy(s['y'][i]):.1f}"
                for i in range(0, len(s["t"]), step)
            )
            dash = f' stroke-dasharray="{s["dash"]}"' if s.get("dash") else ""
            svg.append(
                f'<polyline fill="none" stroke="{s["c"]}" '
                f'stroke-width="1.4"{dash} points="{pts}"/>'
            )
        svg.append(
            f'<rect x="{ml}" y="{y0:.1f}" width="{pw}" '
            f'height="{ph:.1f}" fill="none" stroke="#333333"/>'
        )
        svg.append(
            f'<text x="22" y="{y0+ph/2:.1f}" text-anchor="middle" '
            f'transform="rotate(-90 22 {y0+ph/2:.1f})" '
            f'font-family="Arial" font-size="13" font-weight="bold">'
            f'{pan["ylabel"]}</text>'
        )
    svg.append(
        f'<text x="{ml+pw/2}" y="{H-10}" text-anchor="middle" '
        f'font-family="Arial" font-size="13">{xlabel}</text>'
    )
    lx = ml + 10
    for item in panels[0].get("legend", []):
        svg.append(
            f'<line x1="{lx}" y1="42" x2="{lx+22}" y2="42" '
            f'stroke="{item["c"]}" stroke-dasharray="{item["dash"]}" '
            f'stroke-width="2"/>'
        )
        svg.append(
            f'<text x="{lx+27}" y="46" font-family="Arial" '
            f'font-size="11">{item["txt"]}</text>'
        )
        lx += 245
    svg.append("</svg>")
    svg_path = out / nombre
    pdf_path = svg_path.with_suffix(".pdf")
    svg_path.write_text("\n".join(svg), encoding="utf-8")
    subprocess.run(
        ["rsvg-convert", "-f", "pdf", "-o", str(pdf_path), str(svg_path)],
        check=True,
    )


base = leer_dat("base_media/a18")
cl_rans, cd_rans, cm_rans = (base[1][-1], base[2][-1], base[3][-1]) if base else (1.39656, 0.06290, -0.02168)

ts_raw, cls_raw, cds_raw, cms_raw = leer_dat("urans_stall")
valid = [i for i, t in enumerate(ts_raw) if t >= 0.01 and abs(cls_raw[i]) < 10.0]
ts  = [ts_raw[i]  for i in valid]
cls = [cls_raw[i] for i in valid]
cds = [cds_raw[i] for i in valid]
cms = [cms_raw[i] for i in valid]

idxs = [i for i, t in enumerate(ts) if t >= 0.15]
m_cl = statistics.mean(cls[i] for i in idxs)
m_cd = statistics.mean(cds[i] for i in idxs)
m_cm = statistics.mean(cms[i] for i in idxs)

leg1 = [
    {"c": "#1f77b4", "dash": "", "txt": "URANS backward (urans_stall)"},
    {"c": "#d62728", "dash": "6,4", "txt": "Media URANS (t >= 0.15 s)"},
    {"c": "#2ca02c", "dash": "2,3", "txt": "RANS estacionario base"},
]
p1 = [
    {"ylabel": "cl(t)", "legend": leg1, "series": [{"t": ts, "y": cls, "c": "#1f77b4"}],
     "refs": [{"val": m_cl, "c": "#d62728", "dash": "6,4"}, {"val": cl_rans, "c": "#2ca02c", "dash": "2,3"}]},
    {"ylabel": "cd(t)", "series": [{"t": ts, "y": cds, "c": "#1f77b4"}],
     "refs": [{"val": m_cd, "c": "#d62728", "dash": "6,4"}, {"val": cd_rans, "c": "#2ca02c", "dash": "2,3"}]},
    {"ylabel": "cm,c/4(t)", "series": [{"t": ts, "y": cms, "c": "#1f77b4"}],
     "refs": [{"val": m_cm, "c": "#d62728", "dash": "6,4"}, {"val": cm_rans, "c": "#2ca02c", "dash": "2,3"}]},
]
hacer_svg("fig_p9_historias_coeficientes.svg",
          "NACA 0015 (alpha=18 deg) - Historias temporales URANS (backward)",
          "Tiempo fisico t [s]  (t* = 30 t)", p1, 0.0, 0.50, shade=0.15)

t2, cl2, cd2, cm2 = leer_dat("urans_dt2")
t3, cl3, cd3, cm3 = leer_dat("urans_dt3")
idx15 = [i for i, t in enumerate(t2) if t >= 0.15]
t2s = [t2[i] for i in idx15]
leg2 = [
    {"c": "#1f77b4", "dash": "", "txt": "dt = 1.25e-5 s (urans_dt2)"},
    {"c": "#ff7f0e", "dash": "6,4", "txt": "dt/2 = 6.25e-6 s (urans_dt3)"},
]
p2 = [
    {"ylabel": "cl(t)", "legend": leg2,
     "series": [{"t": t2s, "y": [cl2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cl3, "c": "#ff7f0e", "dash": "6,4"}]},
    {"ylabel": "cd(t)",
     "series": [{"t": t2s, "y": [cd2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cd3, "c": "#ff7f0e", "dash": "6,4"}]},
    {"ylabel": "cm,c/4(t)",
     "series": [{"t": t2s, "y": [cm2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cm3, "c": "#ff7f0e", "dash": "6,4"}]},
]
hacer_svg("fig_p9_comparacion_dt.svg",
          "Verificacion temporal dt vs dt/2 (t* in [4.5, 6.0])",
          "Tiempo fisico t [s]", p2, 0.15, 0.20)
print("OK: SVG y PDF generados en figuras_p9/")
EOF

python3 scripts/generar_figuras_p9.py
ls -lh figuras_p9/*.pdf
