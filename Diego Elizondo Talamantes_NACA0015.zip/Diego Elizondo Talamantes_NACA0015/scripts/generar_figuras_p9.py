import pathlib, re

out = pathlib.Path("figuras_p9")
out.mkdir(exist_ok=True)

def leer_dat(caso):
    p = pathlib.Path("casos") / caso / "postProcessing"
    for f in sorted(p.rglob("*.dat")):
        cols, rows = [], []
        txt = f.read_text(encoding="utf-8", errors="ignore")
        for ln in txt.splitlines():
            s = ln.strip()
            if s.startswith("#") and ("Cl" in s or "Cd" in s):
                cols = s.lstrip("#").split()
            elif s and not s.startswith("#"):
                rows.append([float(x) for x in s.split()])
        if rows and cols:
            idx = {n: i for i, n in enumerate(cols)}
            t = [r[idx.get("Time", 0)] for r in rows]
            cl = [r[idx.get("Cl", 3)] for r in rows]
            cd = [r[idx.get("Cd", 1)] for r in rows]
            cm = [r[idx.get("CmPitch", idx.get("Cm", 2))] for r in rows]
            return t, cl, cd, cm
    return None

for c in ["base_media/a18", "urans_dt2"]:
    p = pathlib.Path("casos") / c / "system/controlDict"
    if p.exists():
        txt = p.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"pitchAxis\s*\(([^)]+)\)", txt)
        print(c, "pitchAxis:", m.group(1) if m else "?")

def hacer_svg(nombre, titulo, xlabel, panels, tmin, tmax, shade=None):
    W, H = 860, 680
    ml, mr, mt, mb = 85, 30, 55, 50
    pw = W - ml - mr
    ph = (H - mt - mb - 40) / 3.0
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">']
    svg.append('<rect width="100%" height="100%" fill="white"/>')
    svg.append(f'<text x="{W/2}" y="26" text-anchor="middle" '
               f'font-family="Arial" font-size="15" font-weight="bold">'
               f'{titulo}</text>')
    for k, pan in enumerate(panels):
        y0 = mt + k * (ph + 15)
        all_y = [v for s in pan["series"] for v in s["y"]]
        for ref in pan.get("refs", []):
            all_y.append(ref["val"])
        ymin, ymax = min(all_y), max(all_y)
        pad = (ymax - ymin) * 0.14 or 0.01
        ymin -= pad
        ymax += pad
        sx = lambda t: ml + (t - tmin) / (tmax - tmin) * pw
        sy = lambda v: y0 + ph - (v - ymin) / (ymax - ymin) * ph
        if shade:
            x_s = sx(shade)
            svg.append(f'<rect x="{ml:.1f}" y="{y0:.1f}" '
                       f'width="{x_s-ml:.1f}" height="{ph:.1f}" '
                       f'fill="#e6e6e6"/>')
        for j in range(5):
            yv = ymin + j * (ymax - ymin) / 4.0
            yp = sy(yv)
            svg.append(f'<line x1="{ml}" y1="{yp:.1f}" x2="{ml+pw}" '
                       f'y2="{yp:.1f}" stroke="#dddddd" stroke-width="1"/>')
            svg.append(f'<text x="{ml-8}" y="{yp+4:.1f}" text-anchor="end" '
                       f'font-family="Arial" font-size="11">{yv:.4f}</text>')
        for j in range(6):
            tv = tmin + j * (tmax - tmin) / 5.0
            xp = sx(tv)
            svg.append(f'<line x1="{xp:.1f}" y1="{y0:.1f}" x2="{xp:.1f}" '
                       f'y2="{y0+ph:.1f}" stroke="#dddddd" stroke-width="1"/>')
            if k == 2:
                svg.append(f'<text x="{xp:.1f}" y="{y0+ph+18:.1f}" '
                           f'text-anchor="middle" font-family="Arial" '
                           f'font-size="11">{tv:.3f}</text>')
        for ref in pan.get("refs", []):
            yr = sy(ref["val"])
            svg.append(f'<line x1="{ml}" y1="{yr:.1f}" x2="{ml+pw}" '
                       f'y2="{yr:.1f}" stroke="{ref["c"]}" '
                       f'stroke-dasharray="{ref["dash"]}" stroke-width="1.5"/>')
        for s in pan["series"]:
            step = max(1, len(s["t"]) // 2500)
            pts = " ".join(f"{sx(s['t'][i]):.1f},{sy(s['y'][i]):.1f}"
                           for i in range(0, len(s["t"]), step))
            dash = f' stroke-dasharray="{s["dash"]}"' if s.get("dash") else ""
            svg.append(f'<polyline fill="none" stroke="{s["c"]}" '
                       f'stroke-width="1.4"{dash} points="{pts}"/>')
        svg.append(f'<rect x="{ml}" y="{y0:.1f}" width="{pw}" '
                   f'height="{ph:.1f}" fill="none" stroke="#333333"/>')
        svg.append(f'<text x="22" y="{y0+ph/2:.1f}" text-anchor="middle" '
                   f'transform="rotate(-90 22 {y0+ph/2:.1f})" '
                   f'font-family="Arial" font-size="13" font-weight="bold">'
                   f'{pan["ylabel"]}</text>')
    svg.append(f'<text x="{ml+pw/2}" y="{H-10}" text-anchor="middle" '
               f'font-family="Arial" font-size="13">{xlabel}</text>')
    lx = ml + 10
    for item in panels[0].get("legend", []):
        svg.append(f'<line x1="{lx}" y1="42" x2="{lx+22}" y2="42" '
                   f'stroke="{item["c"]}" stroke-dasharray="{item["dash"]}" '
                   f'stroke-width="2"/>')
        svg.append(f'<text x="{lx+27}" y="46" font-family="Arial" '
                   f'font-size="11">{item["txt"]}</text>')
        lx += 210
    svg.append("</svg>")
    (out / nombre).write_text("\n".join(svg), encoding="utf-8")

t2, cl2, cd2, cm2 = leer_dat("urans_dt2")
t3, cl3, cd3, cm3 = leer_dat("urans_dt3")

leg1 = [
    {"c": "#1f77b4", "dash": "", "txt": "URANS dt=1.25e-5 s"},
    {"c": "#d62728", "dash": "6,4", "txt": "Media URANS (t >= 0.10 s)"},
    {"c": "#2ca02c", "dash": "2,3", "txt": "RANS estacionario base"},
]
p1 = [
    {"ylabel": "cl(t)", "legend": leg1,
     "series": [{"t": t2, "y": cl2, "c": "#1f77b4"}],
     "refs": [{"val": 1.43287, "c": "#d62728", "dash": "6,4"},
              {"val": 1.39658, "c": "#2ca02c", "dash": "2,3"}]},
    {"ylabel": "cd(t)",
     "series": [{"t": t2, "y": cd2, "c": "#1f77b4"}],
     "refs": [{"val": 0.06230, "c": "#d62728", "dash": "6,4"},
              {"val": 0.06296, "c": "#2ca02c", "dash": "2,3"}]},
    {"ylabel": "cm,c/4(t)",
     "series": [{"t": t2, "y": cm2, "c": "#1f77b4"}],
     "refs": [{"val": -0.01707, "c": "#d62728", "dash": "6,4"}]},
]
hacer_svg("fig_p9_historias_coeficientes.svg",
          "NACA 0015 (alpha=18 deg) - Historias temporales URANS",
          "Tiempo fisico t [s]  (t* = 30 t)", p1, 0.0, 0.20, shade=0.10)

idx15 = [i for i, t in enumerate(t2) if t >= 0.15]
t2s = [t2[i] for i in idx15]
leg2 = [
    {"c": "#1f77b4", "dash": "", "txt": "dt = 1.25e-5 s (urans_dt2)"},
    {"c": "#ff7f0e", "dash": "6,4", "txt": "dt/2 = 6.25e-6 s (urans_dt3)"},
]
p2 = [
    {"ylabel": "cl(t)", "legend": leg2,
     "series": [{"t": t2s, "y": [cl2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cl3, "c": "#ff7f0e", "dash": "6,4"}]},
    {"ylabel": "cd(t)",
     "series": [{"t": t2s, "y": [cd2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cd3, "c": "#ff7f0e", "dash": "6,4"}]},
    {"ylabel": "cm,c/4(t)",
     "series": [{"t": t2s, "y": [cm2[i] for i in idx15], "c": "#1f77b4"},
                {"t": t3, "y": cm3, "c": "#ff7f0e", "dash": "6,4"}]},
]
hacer_svg("fig_p9_comparacion_dt.svg",
          "Verificacion temporal dt vs dt/2 (t* in [4.5, 6.0])",
          "Tiempo fisico t [s]", p2, 0.15, 0.20)
print("OK: SVG generados en figuras_p9/")
