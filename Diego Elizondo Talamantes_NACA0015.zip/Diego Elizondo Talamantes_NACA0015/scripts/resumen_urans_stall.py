import pathlib, statistics, re

f = pathlib.Path("casos/urans_stall/postProcessing/fuerzas/0/forceCoeffs.dat")
rows = []
for ln in f.read_text(encoding="utf-8", errors="ignore").splitlines():
    s = ln.strip()
    if s and not s.startswith("#"):
        rows.append([float(x) for x in s.split()])

sub = [r for r in rows if r[0] >= 0.15]
ts = [r[0] for r in sub]
cms = [r[1] for r in sub]
cds = [r[2] for r in sub]
cls = [r[3] for r in sub]

m_cl, s_cl = statistics.mean(cls), statistics.stdev(cls)
m_cd, s_cd = statistics.mean(cds), statistics.stdev(cds)
m_cm, s_cm = statistics.mean(cms), statistics.stdev(cms)

cruces = [ts[i] for i in range(1, len(cls)) if cls[i-1] < m_cl <= cls[i]]
freq = (len(cruces) - 1) / (cruces[-1] - cruces[0]) if len(cruces) > 1 else 0.0

log = pathlib.Path("casos/urans_stall/log.foamRun").read_text(errors="ignore")
cos = [float(x) for x in re.findall(r"Courant Number mean: [\d.eE+-]+ max: ([\d.eE+-]+)", log)]
co_max = max(cos) if cos else 0.0

print(f"t_fin = {rows[-1][0]:.5f} s (t* = {rows[-1][0]*30:.2f}) | N = {len(sub)}")
print(f"Co_max = {co_max:.4f}")
print(f"Cl = {m_cl:.5f} +- {s_cl:.5f}")
print(f"Cd = {m_cd:.5f} +- {s_cd:.5f}")
print(f"Cm = {m_cm:.5f} +- {s_cm:.5f}")
print(f"f = {freq:.2f} Hz | St_c = {freq/30.0:.4f}")
print(f"LaTeX: {m_cl:.5f} & {m_cd:.5f} & {m_cm:.5f}")
