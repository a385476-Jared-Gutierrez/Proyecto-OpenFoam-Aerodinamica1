import pathlib, re, shutil

c = pathlib.Path("casos/urans_stall")
for f in ["phi", "wallShearStress", "yPlus"]:
    (c/"0"/f).unlink(missing_ok=True)
shutil.rmtree(c/"0/uniform", ignore_errors=True)

hdr = lambda cls, loc, obj: f"FoamFile\n{{\n    format ascii;\n    class {cls};\n    location \"{loc}\";\n    object {obj};\n}}\n"

(c/"0/U").write_text(hdr("volVectorField","0","U") + "dimensions [0 1 -1 0 0 0 0];\ninternalField uniform (28.5317 9.27051 0);\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type noSlip; }\n  inlet { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n  farfield { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n  outlet { type freestreamVelocity; freestreamValue uniform (28.5317 9.27051 0); value uniform (28.5317 9.27051 0); }\n}\n")
(c/"0/p").write_text(hdr("volScalarField","0","p") + "dimensions [0 2 -2 0 0 0 0];\ninternalField uniform 0;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type zeroGradient; }\n  inlet { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n  farfield { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n  outlet { type freestreamPressure; freestreamValue uniform 0; supersonic false; value uniform 0; }\n}\n")
(c/"0/nuTilda").write_text(hdr("volScalarField","0","nuTilda") + "dimensions [0 2 -1 0 0 0 0];\ninternalField uniform 4.3812e-05;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type fixedValue; value uniform 0; }\n  inlet { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n  farfield { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n  outlet { type freestream; freestreamValue uniform 4.3812e-05; value uniform 4.3812e-05; }\n}\n")
(c/"0/nut").write_text(hdr("volScalarField","0","nut") + "dimensions [0 2 -1 0 0 0 0];\ninternalField uniform 3.0733e-06;\nboundaryField {\n  frontAndBack { type empty; }\n  airfoil { type nutUSpaldingWallFunction; Cmu 0.09; kappa 0.41; E 9.8; value uniform 0; }\n  inlet { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n  farfield { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n  outlet { type freestream; freestreamValue uniform 3.0733e-06; value uniform 3.0733e-06; }\n}\n")
(c/"system/decomposeParDict").write_text(hdr("dictionary","system","decomposeParDict") + "numberOfSubdomains 8;\nmethod scotch;\n")

(c/"system/fvSchemes").write_text((c/"system/fvSchemes").read_text(encoding="utf-8").replace("Euler;", "backward;"))
cd = (c/"system/controlDict").read_text(encoding="utf-8")
cd = re.sub(r"endTime\s+0\.20;", "endTime         0.80;", cd)
cd = re.sub(r"deltaT\s+2\.5e-05;", "deltaT          1.25e-05;\nadjustTimeStep  yes;\nmaxCo           2.0;\nmaxDeltaT       5e-05;", cd)
cd = re.sub(r"writeControl\s+runTime;", "writeControl    adjustableRunTime;", cd)
cd = re.sub(r"writeInterval\s+0\.005;", "writeInterval   0.01;", cd)
(c/"system/controlDict").write_text(cd, encoding="utf-8")
print("OK: casos/urans_stall listo")
