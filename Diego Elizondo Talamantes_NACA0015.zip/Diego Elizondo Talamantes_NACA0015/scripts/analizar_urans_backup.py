import pathlib, re, statistics

base = pathlib.Path("casos")
casos = ["base_gruesa", "base_media", "base_fina", "lejano_media",
         "lejano_U30", "urans_dt1", "urans_dt2", "urans_dt3"]

def leer_datos_coef(caso_dir):
    archivos = sorted((caso_dir / "postProcessing").rglob("*.dat"))
    for f in archivos:
        lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()
        cols, rows = [], []
        for ln in lines:
            s = ln.strip()
            if s.startswith("#") and ("Cl" in s or "Cd" in s):
                cols = s.lstrip("#").split()
            elif s and not s.startswith("#"):
                rows.append([float(x) for x in s.split()])
        if rows and cols:
            idx = {name: i for i, name in enumerate(cols)}
            i_t = idx.get("Time", 0)
            i_cd = idx.get("Cd", 1)
            i_cl = idx.get("Cl", 3)
            i_cm = idx.get("CmPitch", idx.get("Cm", 2))
            return [(r[i_t], r[i_cl], r[i_cd], r[i_cm]) for r in rows]
    return None

print("=== RESUMEN DE CONFIGURACION Y RESULTADOS ===")
for nombre in casos:
    d = base / nombre
    if not d.exists():
        continue
    cd_txt = (d / "system/controlDict").read_text(encoding="utf-8", errors="ignore")
    dt = re.search(r"deltaT\s+([0-9.eE+-]+);", cd_txt)
    et = re.search(r"endTime\s+([0-9.eE+-]+);", cd_txt)
    u_txt = (d / "0/U").read_text(encoding="utf-8", errors="ignore")
    u_m = re.search(r"uniform\s*\(([^)]+)\)", u_txt)
    snaps = [p.name for p in d.iterdir() if p.is_dir() and re.match(r"^[0-9.]+$", p.name)]
    datos = leer_datos_coef(d)
    print(f"\n[{nombre}] dt={dt.group(1) if dt else '?'} | endTime={et.group(1) if et else '?'} | U={u_m.group(1) if u_m else '?'} | carpetas_t={len(snaps)}")
    if not datos:
        print("  Sin postProcessing .dat")
        continue
    t_max = datos[-1][0]
    print(f"  Registros: {len(datos)} | t_ini={datos[0][0]:.5f} | t_fin={t_max:.5f} (t*={t_max*30:.2f})")
    if nombre.startswith("base_") or nombre.startswith("lejano_"):
        ult = datos[-1]
        print(f"  Ultimo estado: Cl={ult[1]:.5f}, Cd={ult[2]:.5f}, Cm={ult[3]:.5f}")
    else:
        for t0 in [0.05, 0.10, 0.12]:
            sub = [r for r in datos if r[0] >= t0]
            if len(sub) > 5:
                cl = [r[1] for r in sub]
                cd = [r[2] for r in sub]
                cm = [r[3] for r in sub]
                print(f"  Ventana t>={t0:.2f}s (N={len(sub)}): Cl={statistics.mean(cl):.5f}+-{statistics.stdev(cl):.5f} | Cd={statistics.mean(cd):.5f}+-{statistics.stdev(cd):.5f} | Cm={statistics.mean(cm):.5f}+-{statistics.stdev(cm):.5f}")
