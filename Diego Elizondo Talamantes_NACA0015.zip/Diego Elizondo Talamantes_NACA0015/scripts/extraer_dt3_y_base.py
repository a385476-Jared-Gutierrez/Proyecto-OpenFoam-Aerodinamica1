import pathlib, re, statistics

def stats_dat(caso_dir):
    for f in sorted((caso_dir / "postProcessing").rglob("*.dat")):
        cols, rows = [], []
        for ln in f.read_text(encoding="utf-8", errors="ignore").splitlines():
            s = ln.strip()
            if s.startswith("#") and ("Cl" in s or "Cd" in s):
                cols = s.lstrip("#").split()
            elif s and not s.startswith("#"):
                rows.append([float(x) for x in s.split()])
        if rows and cols:
            idx = {n: i for i, n in enumerate(cols)}
            return [(r[idx.get("Time",0)], r[idx.get("Cl",3)], r[idx.get("Cd",1)], r[idx.get("CmPitch", idx.get("Cm",2))]) for r in rows]
    return None

for nombre in ["urans_dt1", "urans_dt2", "urans_dt3"]:
    d = pathlib.Path("casos") / nombre
    cd = (d / "system/controlDict").read_text(encoding="utf-8", errors="ignore")
    dt = re.search(r"deltaT\s+([0-9.eE+-]+);", cd)
    logs = list(d.glob("log.*"))
    co_max = "?"
    for lg in logs:
        m = re.findall(r"Courant Number mean:\s*[0-9.eE+-]+\s*max:\s*([0-9.eE+-]+)", lg.read_text(encoding="utf-8", errors="ignore"))
        if m:
            co_max = f"{max(float(x) for x in m):.4f} (final={m[-1]})"
    datos = stats_dat(d)
    print(f"\n[{nombre}] dt={dt.group(1) if dt else '?'} | Co_max={co_max}")
    if datos:
        print(f"  t_fin={datos[-1][0]:.5f}s (t*={datos[-1][0]*30:.2f}) | N_total={len(datos)}")
        for t0 in [0.05, 0.10, 0.12]:
            sub = [r for r in datos if r[0] >= t0]
            if len(sub) > 5:
                cl, cd_v, cm = [r[1] for r in sub], [r[2] for r in sub], [r[3] for r in sub]
                print(f"  t>={t0:.2f}s (N={len(sub)}): Cl={statistics.mean(cl):.5f}+-{statistics.stdev(cl):.5f} | Cd={statistics.mean(cd_v):.5f}+-{statistics.stdev(cd_v):.5f} | Cm={statistics.mean(cm):.5f}+-{statistics.stdev(cm):.5f}")

print("\n=== ARCHIVOS CSV/TABLAS EN EL PROYECTO ===")
for p in sorted(pathlib.Path(".").rglob("*")):
    if p.suffix.lower() in [".csv", ".tsv", ".txt"] and "processor" not in str(p):
        print(" ", p)
