PASOS PARA CORRER SIMULACIONES DEL PERFIL NACA 2415
Responsable: Jared Adrian Gutierrez Villalobs

1. Preparacion preliminar y aclaraciones

Todo lo que empieza con # es un comentario: no se escribe.
Cada línea sin # se escribe en la terminal y se presiona Enter.
"python" y "python3" son equivalentes, usar el contrario en caso de que uno no responda.
Estos pasos son correspondientes a la carpeta naca2415, la otra carpeta en este ZIP incluye
unicamente archivos de datos csv, graficas svg y logs ligeros resultantes de la simulacion
previamente hecha.
La se recomienda que la carpeta naca2415 sea copiada a la carpeta "RUN" en OpenFoam, de otra
manera se tendran que modificar los comandos de rutas de archivos en este README


ÍNDICE

PARTE A. SIMULACIONES (OpenFOAM: mallas y corridas)
   1. Preparacion preliminar y aclaraciones
   2. Preparar (una sola vez cada que se inicie la terminal)
   3. La malla media
   4. Primera prueba: un solo ángulo
   5. Estudio de malla (nivel 1): tres mallas, dos ángulos
   6. Barrido de ángulos (nivel 2)
   7. Control de dominio (nivel 2: UN solo perfil del equipo)
   8. Corrida de validación a Re = 6e6 (nivel 3)

PARTE B. POSTPROCESO, GRÁFICAS Y TABLAS (scripts; se corren cuando ya hay resultados)
  9. Gráfica de convergencia de cada simulación
  10. Presión y fricción (cp y cf)
  11. Polar, tabla de cargas y y+
  12. Comparación con el experimento (validación)
  13. ParaView (campos y líneas de corriente)
  14. Resumen: qué comando produce qué para el reporte

#PARTE A. SIMULACIONES (OpenFOAM)                                   

1. PREPARAR (una sola vez)

# Con la carpeta naca2415 ya en "RUN" indicar la ruta en la terminal de OpenFOAM mediante:

cd $FOAM_RUN/naca2415

# Exportar la localizacion de Gmsh (cambiar la ruta por la localizacion de Gmsh en su dispositivo):
export PATH="$PATH:/c/Users/NomUsuario/Desktop/gmsh-4.15.2-Windows64"
gmsh --version                        # debe responder la version del Gmsh del usuario

chmod +x Allmalla Allpolar


3. LA MALLA MEDIA

./Allmalla base media

# Al final imprime dos revisiones de checkMesh:
#   checkMesh sencillo:      debe decir "Mesh OK"
#   checkMesh -allGeometry:  muy probablemente arroje "Failed 1 mesh checks" por la prueba de determinante de celda
#                            (~1500 celdas de capa límite muy alargadas, y+ ~ 1). Es un aviso a declarar en el reporte.
# El detalle está en casos/base_media/log.checkMesh y log.checkMesh_basico.



4. PRIMERA PRUEBA: UN SOLO ÁNGULO

./Allpolar casos/base_media 0

# Correr la simulacion con un solo angulo para confirmar el correcto funcionamiento

5. ESTUDIO DE MALLA (nivel 1)

./Allmalla base gruesa
./Allmalla base fina
./Allpolar casos/base_gruesa 0 8
./Allpolar casos/base_media  0 8
./Allpolar casos/base_fina   0 8
python scripts/estudio_malla.py casos/base_gruesa casos/base_media casos/base_fina

# Proceso de simulacion para nivel 1

6. BARRIDO DE ÁNGULOS (nivel 2) en la malla elegida

# Se realizo la simulacion con 3 nucleos, cambiar el numero de PARALELO segun sea conveniente. No poner
# este comando hara que se use un nucleo para cada angulo hasta que no haya mas angulos o nucleos

PARALELO=3 ./Allpolar casos/base_media 18 17 16 15 14 12 10 8 4 0 -4

# Si se interrumpe: vuelva a correr ESE mismo comando (ver sección 2).
# Si un ángulo sale con "~" porque le faltaron iteraciones, repítalo con más (REHACER=1 porque ya existe):
REHACER=1 ITER=6000 ./Allpolar casos/base_media 18

7. CONTROL DE DOMINIO (nivel 2)

NOMBRE=lejano_U30 UINF=30 R=100 L=100 ./Allmalla lejano media
UINF=30 ./Allpolar casos/lejano_U30 8


8. CORRIDA DE VALIDACIÓN A Re = 6e6 (nivel 3): EL CASO val_Re6e6

NOMBRE=val_Re6e6 UINF=87.6245 ./Allmalla lejano media
PARALELO=3 UINF=87.6245 ./Allpolar casos/val_Re6e6 18 17 16 15 14 12 10 8 4 0 -4



   PARTE B. POSTPROCESO, GRÁFICAS Y TABLAS (scripts)                     

# Estos comandos NO corren simulaciones: leen los resultados que ya están en casos/. Se pueden repetir cuantas veces
# se quiera y se corren después de cada tanda de la Parte A. Todos desde la carpeta naca2415.



10. GRÁFICA DE CONVERGENCIA DE CADA SIMULACIÓN 

# Un comando por caso hace las de todos sus ángulos:
python scripts/graficar_corrida.py casos/base_gruesa
python scripts/graficar_corrida.py casos/base_media
python scripts/graficar_corrida.py casos/base_fina
python scripts/graficar_corrida.py casos/lejano_U30       # cuando exista (sección 7)
python scripts/graficar_corrida.py casos/val_Re6e6        # cuando exista (sección 8)

# Cada una deja convergencia_a<ángulo>.svg dentro de la carpeta del ángulo: ábralo con doble clic (navegador).


11. PRESIÓN Y FRICCIÓN (cp y cf por superficie)

# cp(x/c) de extradós e intradós en TRES ángulos del barrido (uno bajo, uno moderado y uno alto = 18):
python scripts/cp_cf.py casos/base_media/a0 casos/base_media/a8 casos/base_media/a18
# escribe cp_cf_a<ángulo>.csv  y la gráfica .svg dentro de cada carpeta de ángulo.

# El cp también hay que sacarlo en las TRES mallas, en 0 y 8 :
python scripts/cp_cf.py casos/base_gruesa/a0 casos/base_gruesa/a8
python scripts/cp_cf.py casos/base_fina/a0 casos/base_fina/a8
python scripts/cp_cf.py casos/base_media/a0 casos/base_media/a8
# y en el control de dominio (UN perfil), para comparar con base_media a 8:
python scripts/cp_cf.py casos/lejano_U30/a8
# (los scripts no superponen estas curvas: de momento se juntan a mano con los CSV.)



12. POLAR, TABLA DE CARGAS Y y+ (graficar_polar.py)

# --- 1. Barrido de la malla elegida (nivel 2): tabla con cargas, curvas y métricas ---
python scripts/graficar_polar.py casos/base_media

# --- 2. y+(x/c) de la malla elegida: las dos incidencias de verificación y la MAYOR del barrido (obligatorio) ---
python scripts/graficar_polar.py --yplus casos/base_media/a0 casos/base_media/a8 casos/base_media/a18
#   Deja yplus_a0.svg, yplus_a8.svg y yplus_a18.svg dentro de cada carpeta de ángulo

# --- 3. Validación (nivel 3): la polar del caso a Re = 6e6 ---
python scripts/graficar_polar.py casos/val_Re6e6


# --- 4. Opcional: varias mallas en la misma figura ---
python scripts/graficar_polar.py casos/base_gruesa casos/base_media casos/base_fina
#   Deja polar_comparacion.svg y polar_comparacion_tabla.csv en la carpeta donde esté parado.


13. COMPARACIÓN CON EL EXPERIMENTO (nivel 3)

# La comparación con los datos digitalizados de Abbott (referencia/abbott_naca2415_Re6e6.csv):
python scripts/comparar_cl.py casos/val_Re6e6/polar.dat referencia/abbott_naca2415_Re6e6.csv --naca 2415 --rango-lineal -4 8 --salida casos/val_Re6e6/comparacion_cl
